﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Судоку
{
    public class Solver
    {
        public static void Resh(string[,] sudoku, bool LogFlag)
        {
            Stack<string> stackPossibleValues = new Stack<string>();
            int Z = 0;
            if (LogFlag) File.AppendAllText(Form1.Folder, "Запускаю алгоритм \"Единственный кандидат\" \r\n");
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    for (int n = 1; n <= 9; n++)
                    {
                        if ((sudoku[i, j] == "0") && (Stroka(sudoku, n, i) == true)
                            && (Stolbec(sudoku, n, j) == true) && (Kv(sudoku, n, i, j) == true))
                        {
                            stackPossibleValues.Push(Convert.ToString(n));
                            Z = n;
                        }
                    }
                    if (stackPossibleValues.Count == 1)
                    {
                        if (LogFlag)
                        {
                            string Log = "В ячейке " + "(" + Convert.ToString(i) + "," + Convert.ToString(j) + ")" + " может стоять только число " + Convert.ToString(Z) + ", значит смело его ставим в ячейку \r\n";
                            File.AppendAllText(Form1.Folder, Log);
                        }
                        sudoku[i, j] = stackPossibleValues.Pop();
                    }
                    Z = 0;
                    stackPossibleValues.Clear();
                }
            }
        }
        public static bool Stroka(string[,] array, int number, int k)
        {
            bool chi = true;
            for (int j = 0; j < 9; j++)
            {
                if (Convert.ToInt32(array[k, j]) == number)
                {
                    chi = false;
                    break;
                }
            }
            return chi;
        }
        public static bool Stolbec(string[,] array, int number, int k)
        {
            bool chi = true;
            for (int i = 0; i < 9; i++)
            {
                if (Convert.ToInt32(array[i, k]) == number)
                {
                    chi = false;
                    break;
                }
            }
            return chi;
        }
        public static bool Kv(string[,] array, int number, int k, int l)
        {
            bool chi = true;
            //Первый
            if (k < 3 && l < 3)
            {
                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        if (Convert.ToInt32(array[i, j]) == number)  //number это текущее число n
                        {
                            chi = false;
                        }
                    }
                }
            }
            //Второй
            if (k < 3 && l >= 3 && l < 6)
            {
                for (int i = 0; i <= 2; i++)
                {
                    for (int j = 3; j < 6; j++)
                    {
                        if (Convert.ToInt32(array[i, j]) == number)
                        {
                            chi = false;
                        }
                    }
                }
            }
            //Третий

            if (k < 3 && l >= 6 && l < 9)
            {
                for (int i = 0; i <= 2; i++)
                {
                    for (int j = 6; j <= 8; j++)
                    {
                        if (Convert.ToInt32(array[i, j]) == number)
                        {
                            chi = false;
                        }
                    }
                }
            }
            //Четвертый
            if (k >= 3 && k < 6 && l < 3)
            {
                for (int i = 3; i < 6; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        if (Convert.ToInt32(array[i, j]) == number)
                        {
                            chi = false;
                        }
                    }
                }
            }
            //Пятый
            if (k >= 3 && k < 6 && l >= 3 && l <= 5)
            {
                for (int i = 3; i <= 5; i++)
                {
                    for (int j = 3; j <= 5; j++)
                    {
                        if (Convert.ToInt32(array[i, j]) == number)
                        {
                            chi = false;
                        }
                    }
                }
            }
            //Шестой
            if (k >= 3 && k <= 5 && l >= 6)
            {
                for (int i = 3; i <= 5; i++)
                {
                    for (int j = 6; j <= 8; j++)
                    {
                        if (Convert.ToInt32(array[i, j]) == number)
                        {
                            chi = false;
                        }
                    }
                }
            }
            //Седьмой
            if (k >= 6 && k < 9 && l <= 2)
            {
                for (int i = 6; i <= 8; i++)
                {
                    for (int j = 0; j <= 2; j++)
                    {
                        if (Convert.ToInt32(array[i, j]) == number)
                        {
                            chi = false;
                        }
                    }
                }
            }
            //Восьмой
            if (k >= 6 && l >= 3 && l < 6)
            {
                for (int i = 6; i < 9; i++)
                {
                    for (int j = 3; j <= 5; j++)
                    {
                        if (Convert.ToInt32(array[i, j]) == number)
                        {
                            chi = false;
                        }
                    }
                }
            }
            //Девятый
            if (k >= 6 && l >= 6)
            {
                for (int i = 6; i < 9; i++)
                {
                    for (int j = 6; j < 9; j++)
                    {
                        if (Convert.ToInt32(array[i, j]) == number)
                        {
                            chi = false;
                        }
                    }
                }
            }
            return chi;
        }
    }
}
