﻿namespace Судоку
{
    partial class trueSudoku
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.textBox79 = new System.Windows.Forms.TextBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.textBox87 = new System.Windows.Forms.TextBox();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.textBox90 = new System.Windows.Forms.TextBox();
            this.textBox91 = new System.Windows.Forms.TextBox();
            this.textBox92 = new System.Windows.Forms.TextBox();
            this.textBox93 = new System.Windows.Forms.TextBox();
            this.textBox94 = new System.Windows.Forms.TextBox();
            this.textBox95 = new System.Windows.Forms.TextBox();
            this.textBox96 = new System.Windows.Forms.TextBox();
            this.textBox97 = new System.Windows.Forms.TextBox();
            this.textBox98 = new System.Windows.Forms.TextBox();
            this.textBox99 = new System.Windows.Forms.TextBox();
            this.textBox100 = new System.Windows.Forms.TextBox();
            this.textBox101 = new System.Windows.Forms.TextBox();
            this.textBox102 = new System.Windows.Forms.TextBox();
            this.textBox103 = new System.Windows.Forms.TextBox();
            this.textBox104 = new System.Windows.Forms.TextBox();
            this.textBox105 = new System.Windows.Forms.TextBox();
            this.textBox106 = new System.Windows.Forms.TextBox();
            this.textBox107 = new System.Windows.Forms.TextBox();
            this.textBox108 = new System.Windows.Forms.TextBox();
            this.textBox109 = new System.Windows.Forms.TextBox();
            this.textBox110 = new System.Windows.Forms.TextBox();
            this.textBox111 = new System.Windows.Forms.TextBox();
            this.textBox112 = new System.Windows.Forms.TextBox();
            this.textBox113 = new System.Windows.Forms.TextBox();
            this.textBox114 = new System.Windows.Forms.TextBox();
            this.textBox115 = new System.Windows.Forms.TextBox();
            this.textBox116 = new System.Windows.Forms.TextBox();
            this.textBox117 = new System.Windows.Forms.TextBox();
            this.textBox118 = new System.Windows.Forms.TextBox();
            this.textBox119 = new System.Windows.Forms.TextBox();
            this.textBox120 = new System.Windows.Forms.TextBox();
            this.textBox121 = new System.Windows.Forms.TextBox();
            this.textBox122 = new System.Windows.Forms.TextBox();
            this.textBox123 = new System.Windows.Forms.TextBox();
            this.textBox124 = new System.Windows.Forms.TextBox();
            this.textBox125 = new System.Windows.Forms.TextBox();
            this.textBox126 = new System.Windows.Forms.TextBox();
            this.textBox127 = new System.Windows.Forms.TextBox();
            this.textBox128 = new System.Windows.Forms.TextBox();
            this.textBox129 = new System.Windows.Forms.TextBox();
            this.textBox130 = new System.Windows.Forms.TextBox();
            this.textBox131 = new System.Windows.Forms.TextBox();
            this.textBox132 = new System.Windows.Forms.TextBox();
            this.textBox133 = new System.Windows.Forms.TextBox();
            this.textBox134 = new System.Windows.Forms.TextBox();
            this.textBox135 = new System.Windows.Forms.TextBox();
            this.textBox136 = new System.Windows.Forms.TextBox();
            this.textBox137 = new System.Windows.Forms.TextBox();
            this.textBox138 = new System.Windows.Forms.TextBox();
            this.textBox139 = new System.Windows.Forms.TextBox();
            this.textBox140 = new System.Windows.Forms.TextBox();
            this.textBox141 = new System.Windows.Forms.TextBox();
            this.textBox142 = new System.Windows.Forms.TextBox();
            this.textBox143 = new System.Windows.Forms.TextBox();
            this.textBox144 = new System.Windows.Forms.TextBox();
            this.textBox145 = new System.Windows.Forms.TextBox();
            this.textBox146 = new System.Windows.Forms.TextBox();
            this.textBox147 = new System.Windows.Forms.TextBox();
            this.textBox148 = new System.Windows.Forms.TextBox();
            this.textBox149 = new System.Windows.Forms.TextBox();
            this.textBox150 = new System.Windows.Forms.TextBox();
            this.textBox151 = new System.Windows.Forms.TextBox();
            this.textBox152 = new System.Windows.Forms.TextBox();
            this.textBox153 = new System.Windows.Forms.TextBox();
            this.textBox154 = new System.Windows.Forms.TextBox();
            this.textBox155 = new System.Windows.Forms.TextBox();
            this.textBox156 = new System.Windows.Forms.TextBox();
            this.textBox157 = new System.Windows.Forms.TextBox();
            this.textBox158 = new System.Windows.Forms.TextBox();
            this.textBox159 = new System.Windows.Forms.TextBox();
            this.textBox160 = new System.Windows.Forms.TextBox();
            this.textBox161 = new System.Windows.Forms.TextBox();
            this.textBox162 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox73
            // 
            this.textBox73.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox73.Location = new System.Drawing.Point(305, 311);
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(28, 30);
            this.textBox73.TabIndex = 234;
            // 
            // textBox74
            // 
            this.textBox74.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox74.Location = new System.Drawing.Point(280, 311);
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(28, 30);
            this.textBox74.TabIndex = 233;
            // 
            // textBox75
            // 
            this.textBox75.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox75.Location = new System.Drawing.Point(257, 311);
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(28, 30);
            this.textBox75.TabIndex = 232;
            // 
            // textBox76
            // 
            this.textBox76.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox76.Location = new System.Drawing.Point(305, 283);
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(28, 30);
            this.textBox76.TabIndex = 231;
            // 
            // textBox77
            // 
            this.textBox77.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox77.Location = new System.Drawing.Point(280, 283);
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(28, 30);
            this.textBox77.TabIndex = 230;
            // 
            // textBox78
            // 
            this.textBox78.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox78.Location = new System.Drawing.Point(257, 283);
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(28, 30);
            this.textBox78.TabIndex = 229;
            // 
            // textBox79
            // 
            this.textBox79.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox79.Location = new System.Drawing.Point(305, 255);
            this.textBox79.Name = "textBox79";
            this.textBox79.Size = new System.Drawing.Size(28, 30);
            this.textBox79.TabIndex = 228;
            // 
            // textBox80
            // 
            this.textBox80.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox80.Location = new System.Drawing.Point(280, 255);
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(28, 30);
            this.textBox80.TabIndex = 227;
            // 
            // textBox81
            // 
            this.textBox81.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox81.Location = new System.Drawing.Point(257, 255);
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(28, 30);
            this.textBox81.TabIndex = 226;
            // 
            // textBox64
            // 
            this.textBox64.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox64.Location = new System.Drawing.Point(221, 311);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(28, 30);
            this.textBox64.TabIndex = 225;
            // 
            // textBox65
            // 
            this.textBox65.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox65.Location = new System.Drawing.Point(194, 311);
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(28, 30);
            this.textBox65.TabIndex = 224;
            // 
            // textBox66
            // 
            this.textBox66.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox66.Location = new System.Drawing.Point(167, 311);
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(28, 30);
            this.textBox66.TabIndex = 223;
            // 
            // textBox67
            // 
            this.textBox67.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox67.Location = new System.Drawing.Point(221, 283);
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(28, 30);
            this.textBox67.TabIndex = 222;
            // 
            // textBox68
            // 
            this.textBox68.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox68.Location = new System.Drawing.Point(194, 283);
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(28, 30);
            this.textBox68.TabIndex = 221;
            // 
            // textBox69
            // 
            this.textBox69.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox69.Location = new System.Drawing.Point(167, 283);
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(28, 30);
            this.textBox69.TabIndex = 220;
            // 
            // textBox70
            // 
            this.textBox70.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox70.Location = new System.Drawing.Point(221, 255);
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(28, 30);
            this.textBox70.TabIndex = 219;
            // 
            // textBox71
            // 
            this.textBox71.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox71.Location = new System.Drawing.Point(194, 255);
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(28, 30);
            this.textBox71.TabIndex = 218;
            // 
            // textBox72
            // 
            this.textBox72.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox72.Location = new System.Drawing.Point(167, 255);
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(28, 30);
            this.textBox72.TabIndex = 217;
            // 
            // textBox55
            // 
            this.textBox55.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox55.Location = new System.Drawing.Point(131, 311);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(28, 30);
            this.textBox55.TabIndex = 216;
            // 
            // textBox56
            // 
            this.textBox56.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox56.Location = new System.Drawing.Point(104, 311);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(28, 30);
            this.textBox56.TabIndex = 215;
            // 
            // textBox57
            // 
            this.textBox57.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox57.Location = new System.Drawing.Point(79, 311);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(28, 30);
            this.textBox57.TabIndex = 214;
            // 
            // textBox58
            // 
            this.textBox58.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox58.Location = new System.Drawing.Point(131, 283);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(28, 30);
            this.textBox58.TabIndex = 213;
            // 
            // textBox59
            // 
            this.textBox59.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox59.Location = new System.Drawing.Point(104, 283);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(28, 30);
            this.textBox59.TabIndex = 212;
            // 
            // textBox60
            // 
            this.textBox60.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox60.Location = new System.Drawing.Point(79, 283);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(28, 30);
            this.textBox60.TabIndex = 211;
            // 
            // textBox61
            // 
            this.textBox61.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox61.Location = new System.Drawing.Point(131, 255);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(28, 30);
            this.textBox61.TabIndex = 210;
            // 
            // textBox62
            // 
            this.textBox62.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox62.Location = new System.Drawing.Point(104, 255);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(28, 30);
            this.textBox62.TabIndex = 209;
            // 
            // textBox63
            // 
            this.textBox63.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox63.Location = new System.Drawing.Point(79, 255);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(28, 30);
            this.textBox63.TabIndex = 208;
            // 
            // textBox46
            // 
            this.textBox46.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox46.Location = new System.Drawing.Point(305, 216);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(28, 30);
            this.textBox46.TabIndex = 207;
            // 
            // textBox47
            // 
            this.textBox47.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox47.Location = new System.Drawing.Point(280, 216);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(28, 30);
            this.textBox47.TabIndex = 206;
            // 
            // textBox48
            // 
            this.textBox48.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox48.Location = new System.Drawing.Point(257, 216);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(28, 30);
            this.textBox48.TabIndex = 205;
            // 
            // textBox49
            // 
            this.textBox49.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox49.Location = new System.Drawing.Point(305, 188);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(28, 30);
            this.textBox49.TabIndex = 204;
            // 
            // textBox50
            // 
            this.textBox50.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox50.Location = new System.Drawing.Point(280, 188);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(28, 30);
            this.textBox50.TabIndex = 203;
            // 
            // textBox51
            // 
            this.textBox51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox51.Location = new System.Drawing.Point(257, 188);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(28, 30);
            this.textBox51.TabIndex = 202;
            // 
            // textBox52
            // 
            this.textBox52.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox52.Location = new System.Drawing.Point(305, 160);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(28, 30);
            this.textBox52.TabIndex = 201;
            // 
            // textBox53
            // 
            this.textBox53.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox53.Location = new System.Drawing.Point(280, 160);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(28, 30);
            this.textBox53.TabIndex = 200;
            // 
            // textBox54
            // 
            this.textBox54.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox54.Location = new System.Drawing.Point(257, 160);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(28, 30);
            this.textBox54.TabIndex = 199;
            // 
            // textBox37
            // 
            this.textBox37.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox37.Location = new System.Drawing.Point(221, 216);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(28, 30);
            this.textBox37.TabIndex = 198;
            // 
            // textBox38
            // 
            this.textBox38.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox38.Location = new System.Drawing.Point(194, 216);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(28, 30);
            this.textBox38.TabIndex = 197;
            // 
            // textBox39
            // 
            this.textBox39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox39.Location = new System.Drawing.Point(167, 216);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(28, 30);
            this.textBox39.TabIndex = 196;
            // 
            // textBox40
            // 
            this.textBox40.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox40.Location = new System.Drawing.Point(221, 188);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(28, 30);
            this.textBox40.TabIndex = 195;
            // 
            // textBox41
            // 
            this.textBox41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox41.Location = new System.Drawing.Point(194, 188);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(28, 30);
            this.textBox41.TabIndex = 194;
            // 
            // textBox42
            // 
            this.textBox42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox42.Location = new System.Drawing.Point(167, 188);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(28, 30);
            this.textBox42.TabIndex = 193;
            // 
            // textBox43
            // 
            this.textBox43.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox43.Location = new System.Drawing.Point(221, 160);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(28, 30);
            this.textBox43.TabIndex = 192;
            // 
            // textBox44
            // 
            this.textBox44.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox44.Location = new System.Drawing.Point(194, 160);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(28, 30);
            this.textBox44.TabIndex = 191;
            // 
            // textBox45
            // 
            this.textBox45.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox45.Location = new System.Drawing.Point(167, 160);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(28, 30);
            this.textBox45.TabIndex = 190;
            // 
            // textBox28
            // 
            this.textBox28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox28.Location = new System.Drawing.Point(131, 216);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(28, 30);
            this.textBox28.TabIndex = 189;
            // 
            // textBox29
            // 
            this.textBox29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox29.Location = new System.Drawing.Point(104, 216);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(28, 30);
            this.textBox29.TabIndex = 188;
            // 
            // textBox30
            // 
            this.textBox30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox30.Location = new System.Drawing.Point(79, 216);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(28, 30);
            this.textBox30.TabIndex = 187;
            // 
            // textBox31
            // 
            this.textBox31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox31.Location = new System.Drawing.Point(131, 188);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(28, 30);
            this.textBox31.TabIndex = 186;
            // 
            // textBox32
            // 
            this.textBox32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox32.Location = new System.Drawing.Point(104, 188);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(28, 30);
            this.textBox32.TabIndex = 185;
            // 
            // textBox33
            // 
            this.textBox33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox33.Location = new System.Drawing.Point(79, 188);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(28, 30);
            this.textBox33.TabIndex = 184;
            // 
            // textBox34
            // 
            this.textBox34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox34.Location = new System.Drawing.Point(131, 160);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(28, 30);
            this.textBox34.TabIndex = 183;
            // 
            // textBox35
            // 
            this.textBox35.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox35.Location = new System.Drawing.Point(104, 160);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(28, 30);
            this.textBox35.TabIndex = 182;
            // 
            // textBox36
            // 
            this.textBox36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox36.Location = new System.Drawing.Point(79, 160);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(28, 30);
            this.textBox36.TabIndex = 181;
            // 
            // textBox19
            // 
            this.textBox19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox19.Location = new System.Drawing.Point(305, 120);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(28, 30);
            this.textBox19.TabIndex = 180;
            // 
            // textBox20
            // 
            this.textBox20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox20.Location = new System.Drawing.Point(280, 120);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(28, 30);
            this.textBox20.TabIndex = 179;
            // 
            // textBox21
            // 
            this.textBox21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox21.Location = new System.Drawing.Point(257, 120);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(28, 30);
            this.textBox21.TabIndex = 178;
            // 
            // textBox22
            // 
            this.textBox22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox22.Location = new System.Drawing.Point(305, 92);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(28, 30);
            this.textBox22.TabIndex = 177;
            // 
            // textBox23
            // 
            this.textBox23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox23.Location = new System.Drawing.Point(280, 92);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(28, 30);
            this.textBox23.TabIndex = 176;
            // 
            // textBox24
            // 
            this.textBox24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox24.Location = new System.Drawing.Point(257, 92);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(28, 30);
            this.textBox24.TabIndex = 175;
            // 
            // textBox25
            // 
            this.textBox25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox25.Location = new System.Drawing.Point(305, 64);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(28, 30);
            this.textBox25.TabIndex = 174;
            // 
            // textBox26
            // 
            this.textBox26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox26.Location = new System.Drawing.Point(280, 64);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(28, 30);
            this.textBox26.TabIndex = 173;
            // 
            // textBox27
            // 
            this.textBox27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox27.Location = new System.Drawing.Point(257, 64);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(28, 30);
            this.textBox27.TabIndex = 172;
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10.Location = new System.Drawing.Point(167, 64);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(28, 30);
            this.textBox10.TabIndex = 171;
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11.Location = new System.Drawing.Point(194, 64);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(28, 30);
            this.textBox11.TabIndex = 170;
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12.Location = new System.Drawing.Point(221, 64);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(28, 30);
            this.textBox12.TabIndex = 169;
            // 
            // textBox13
            // 
            this.textBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox13.Location = new System.Drawing.Point(167, 120);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(28, 30);
            this.textBox13.TabIndex = 168;
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox14.Location = new System.Drawing.Point(167, 92);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(28, 30);
            this.textBox14.TabIndex = 167;
            // 
            // textBox15
            // 
            this.textBox15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox15.Location = new System.Drawing.Point(194, 92);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(28, 30);
            this.textBox15.TabIndex = 166;
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox16.Location = new System.Drawing.Point(221, 92);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(28, 30);
            this.textBox16.TabIndex = 165;
            // 
            // textBox17
            // 
            this.textBox17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox17.Location = new System.Drawing.Point(194, 120);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(28, 30);
            this.textBox17.TabIndex = 164;
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox18.Location = new System.Drawing.Point(221, 120);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(28, 30);
            this.textBox18.TabIndex = 163;
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9.Location = new System.Drawing.Point(131, 120);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(28, 30);
            this.textBox9.TabIndex = 162;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox8.Location = new System.Drawing.Point(104, 120);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(28, 30);
            this.textBox8.TabIndex = 161;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox7.Location = new System.Drawing.Point(79, 120);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(28, 30);
            this.textBox7.TabIndex = 160;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox6.Location = new System.Drawing.Point(131, 92);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(28, 30);
            this.textBox6.TabIndex = 159;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox5.Location = new System.Drawing.Point(104, 92);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(28, 30);
            this.textBox5.TabIndex = 158;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox4.Location = new System.Drawing.Point(79, 92);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(28, 30);
            this.textBox4.TabIndex = 157;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox3.Location = new System.Drawing.Point(131, 64);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(28, 30);
            this.textBox3.TabIndex = 156;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox2.Location = new System.Drawing.Point(104, 64);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(28, 30);
            this.textBox2.TabIndex = 155;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(79, 64);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(28, 30);
            this.textBox1.TabIndex = 154;
            // 
            // textBox82
            // 
            this.textBox82.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox82.Location = new System.Drawing.Point(687, 311);
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(28, 30);
            this.textBox82.TabIndex = 315;
            // 
            // textBox83
            // 
            this.textBox83.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox83.Location = new System.Drawing.Point(662, 311);
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new System.Drawing.Size(28, 30);
            this.textBox83.TabIndex = 314;
            // 
            // textBox84
            // 
            this.textBox84.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox84.Location = new System.Drawing.Point(639, 311);
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new System.Drawing.Size(28, 30);
            this.textBox84.TabIndex = 313;
            // 
            // textBox85
            // 
            this.textBox85.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox85.Location = new System.Drawing.Point(687, 283);
            this.textBox85.Name = "textBox85";
            this.textBox85.Size = new System.Drawing.Size(28, 30);
            this.textBox85.TabIndex = 312;
            // 
            // textBox86
            // 
            this.textBox86.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox86.Location = new System.Drawing.Point(662, 283);
            this.textBox86.Name = "textBox86";
            this.textBox86.Size = new System.Drawing.Size(28, 30);
            this.textBox86.TabIndex = 311;
            // 
            // textBox87
            // 
            this.textBox87.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox87.Location = new System.Drawing.Point(639, 283);
            this.textBox87.Name = "textBox87";
            this.textBox87.Size = new System.Drawing.Size(28, 30);
            this.textBox87.TabIndex = 310;
            // 
            // textBox88
            // 
            this.textBox88.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox88.Location = new System.Drawing.Point(687, 255);
            this.textBox88.Name = "textBox88";
            this.textBox88.Size = new System.Drawing.Size(28, 30);
            this.textBox88.TabIndex = 309;
            // 
            // textBox89
            // 
            this.textBox89.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox89.Location = new System.Drawing.Point(662, 255);
            this.textBox89.Name = "textBox89";
            this.textBox89.Size = new System.Drawing.Size(28, 30);
            this.textBox89.TabIndex = 308;
            // 
            // textBox90
            // 
            this.textBox90.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox90.Location = new System.Drawing.Point(639, 255);
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new System.Drawing.Size(28, 30);
            this.textBox90.TabIndex = 307;
            // 
            // textBox91
            // 
            this.textBox91.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox91.Location = new System.Drawing.Point(603, 311);
            this.textBox91.Name = "textBox91";
            this.textBox91.Size = new System.Drawing.Size(28, 30);
            this.textBox91.TabIndex = 306;
            // 
            // textBox92
            // 
            this.textBox92.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox92.Location = new System.Drawing.Point(576, 311);
            this.textBox92.Name = "textBox92";
            this.textBox92.Size = new System.Drawing.Size(28, 30);
            this.textBox92.TabIndex = 305;
            // 
            // textBox93
            // 
            this.textBox93.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox93.Location = new System.Drawing.Point(549, 311);
            this.textBox93.Name = "textBox93";
            this.textBox93.Size = new System.Drawing.Size(28, 30);
            this.textBox93.TabIndex = 304;
            // 
            // textBox94
            // 
            this.textBox94.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox94.Location = new System.Drawing.Point(603, 283);
            this.textBox94.Name = "textBox94";
            this.textBox94.Size = new System.Drawing.Size(28, 30);
            this.textBox94.TabIndex = 303;
            // 
            // textBox95
            // 
            this.textBox95.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox95.Location = new System.Drawing.Point(576, 283);
            this.textBox95.Name = "textBox95";
            this.textBox95.Size = new System.Drawing.Size(28, 30);
            this.textBox95.TabIndex = 302;
            // 
            // textBox96
            // 
            this.textBox96.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox96.Location = new System.Drawing.Point(549, 283);
            this.textBox96.Name = "textBox96";
            this.textBox96.Size = new System.Drawing.Size(28, 30);
            this.textBox96.TabIndex = 301;
            // 
            // textBox97
            // 
            this.textBox97.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox97.Location = new System.Drawing.Point(603, 255);
            this.textBox97.Name = "textBox97";
            this.textBox97.Size = new System.Drawing.Size(28, 30);
            this.textBox97.TabIndex = 300;
            // 
            // textBox98
            // 
            this.textBox98.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox98.Location = new System.Drawing.Point(576, 255);
            this.textBox98.Name = "textBox98";
            this.textBox98.Size = new System.Drawing.Size(28, 30);
            this.textBox98.TabIndex = 299;
            // 
            // textBox99
            // 
            this.textBox99.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox99.Location = new System.Drawing.Point(549, 255);
            this.textBox99.Name = "textBox99";
            this.textBox99.Size = new System.Drawing.Size(28, 30);
            this.textBox99.TabIndex = 298;
            // 
            // textBox100
            // 
            this.textBox100.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox100.Location = new System.Drawing.Point(513, 311);
            this.textBox100.Name = "textBox100";
            this.textBox100.Size = new System.Drawing.Size(28, 30);
            this.textBox100.TabIndex = 297;
            // 
            // textBox101
            // 
            this.textBox101.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox101.Location = new System.Drawing.Point(486, 311);
            this.textBox101.Name = "textBox101";
            this.textBox101.Size = new System.Drawing.Size(28, 30);
            this.textBox101.TabIndex = 296;
            // 
            // textBox102
            // 
            this.textBox102.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox102.Location = new System.Drawing.Point(461, 311);
            this.textBox102.Name = "textBox102";
            this.textBox102.Size = new System.Drawing.Size(28, 30);
            this.textBox102.TabIndex = 295;
            // 
            // textBox103
            // 
            this.textBox103.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox103.Location = new System.Drawing.Point(513, 283);
            this.textBox103.Name = "textBox103";
            this.textBox103.Size = new System.Drawing.Size(28, 30);
            this.textBox103.TabIndex = 294;
            // 
            // textBox104
            // 
            this.textBox104.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox104.Location = new System.Drawing.Point(486, 283);
            this.textBox104.Name = "textBox104";
            this.textBox104.Size = new System.Drawing.Size(28, 30);
            this.textBox104.TabIndex = 293;
            // 
            // textBox105
            // 
            this.textBox105.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox105.Location = new System.Drawing.Point(461, 283);
            this.textBox105.Name = "textBox105";
            this.textBox105.Size = new System.Drawing.Size(28, 30);
            this.textBox105.TabIndex = 292;
            // 
            // textBox106
            // 
            this.textBox106.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox106.Location = new System.Drawing.Point(513, 255);
            this.textBox106.Name = "textBox106";
            this.textBox106.Size = new System.Drawing.Size(28, 30);
            this.textBox106.TabIndex = 291;
            // 
            // textBox107
            // 
            this.textBox107.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox107.Location = new System.Drawing.Point(486, 255);
            this.textBox107.Name = "textBox107";
            this.textBox107.Size = new System.Drawing.Size(28, 30);
            this.textBox107.TabIndex = 290;
            // 
            // textBox108
            // 
            this.textBox108.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox108.Location = new System.Drawing.Point(461, 255);
            this.textBox108.Name = "textBox108";
            this.textBox108.Size = new System.Drawing.Size(28, 30);
            this.textBox108.TabIndex = 289;
            // 
            // textBox109
            // 
            this.textBox109.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox109.Location = new System.Drawing.Point(687, 216);
            this.textBox109.Name = "textBox109";
            this.textBox109.Size = new System.Drawing.Size(28, 30);
            this.textBox109.TabIndex = 288;
            // 
            // textBox110
            // 
            this.textBox110.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox110.Location = new System.Drawing.Point(662, 216);
            this.textBox110.Name = "textBox110";
            this.textBox110.Size = new System.Drawing.Size(28, 30);
            this.textBox110.TabIndex = 287;
            // 
            // textBox111
            // 
            this.textBox111.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox111.Location = new System.Drawing.Point(639, 216);
            this.textBox111.Name = "textBox111";
            this.textBox111.Size = new System.Drawing.Size(28, 30);
            this.textBox111.TabIndex = 286;
            // 
            // textBox112
            // 
            this.textBox112.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox112.Location = new System.Drawing.Point(687, 188);
            this.textBox112.Name = "textBox112";
            this.textBox112.Size = new System.Drawing.Size(28, 30);
            this.textBox112.TabIndex = 285;
            // 
            // textBox113
            // 
            this.textBox113.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox113.Location = new System.Drawing.Point(662, 188);
            this.textBox113.Name = "textBox113";
            this.textBox113.Size = new System.Drawing.Size(28, 30);
            this.textBox113.TabIndex = 284;
            // 
            // textBox114
            // 
            this.textBox114.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox114.Location = new System.Drawing.Point(639, 188);
            this.textBox114.Name = "textBox114";
            this.textBox114.Size = new System.Drawing.Size(28, 30);
            this.textBox114.TabIndex = 283;
            // 
            // textBox115
            // 
            this.textBox115.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox115.Location = new System.Drawing.Point(687, 160);
            this.textBox115.Name = "textBox115";
            this.textBox115.Size = new System.Drawing.Size(28, 30);
            this.textBox115.TabIndex = 282;
            // 
            // textBox116
            // 
            this.textBox116.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox116.Location = new System.Drawing.Point(662, 160);
            this.textBox116.Name = "textBox116";
            this.textBox116.Size = new System.Drawing.Size(28, 30);
            this.textBox116.TabIndex = 281;
            // 
            // textBox117
            // 
            this.textBox117.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox117.Location = new System.Drawing.Point(639, 160);
            this.textBox117.Name = "textBox117";
            this.textBox117.Size = new System.Drawing.Size(28, 30);
            this.textBox117.TabIndex = 280;
            // 
            // textBox118
            // 
            this.textBox118.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox118.Location = new System.Drawing.Point(603, 216);
            this.textBox118.Name = "textBox118";
            this.textBox118.Size = new System.Drawing.Size(28, 30);
            this.textBox118.TabIndex = 279;
            // 
            // textBox119
            // 
            this.textBox119.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox119.Location = new System.Drawing.Point(576, 216);
            this.textBox119.Name = "textBox119";
            this.textBox119.Size = new System.Drawing.Size(28, 30);
            this.textBox119.TabIndex = 278;
            // 
            // textBox120
            // 
            this.textBox120.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox120.Location = new System.Drawing.Point(549, 216);
            this.textBox120.Name = "textBox120";
            this.textBox120.Size = new System.Drawing.Size(28, 30);
            this.textBox120.TabIndex = 277;
            // 
            // textBox121
            // 
            this.textBox121.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox121.Location = new System.Drawing.Point(603, 188);
            this.textBox121.Name = "textBox121";
            this.textBox121.Size = new System.Drawing.Size(28, 30);
            this.textBox121.TabIndex = 276;
            // 
            // textBox122
            // 
            this.textBox122.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox122.Location = new System.Drawing.Point(576, 188);
            this.textBox122.Name = "textBox122";
            this.textBox122.Size = new System.Drawing.Size(28, 30);
            this.textBox122.TabIndex = 275;
            // 
            // textBox123
            // 
            this.textBox123.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox123.Location = new System.Drawing.Point(549, 188);
            this.textBox123.Name = "textBox123";
            this.textBox123.Size = new System.Drawing.Size(28, 30);
            this.textBox123.TabIndex = 274;
            // 
            // textBox124
            // 
            this.textBox124.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox124.Location = new System.Drawing.Point(603, 160);
            this.textBox124.Name = "textBox124";
            this.textBox124.Size = new System.Drawing.Size(28, 30);
            this.textBox124.TabIndex = 273;
            // 
            // textBox125
            // 
            this.textBox125.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox125.Location = new System.Drawing.Point(576, 160);
            this.textBox125.Name = "textBox125";
            this.textBox125.Size = new System.Drawing.Size(28, 30);
            this.textBox125.TabIndex = 272;
            // 
            // textBox126
            // 
            this.textBox126.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox126.Location = new System.Drawing.Point(549, 160);
            this.textBox126.Name = "textBox126";
            this.textBox126.Size = new System.Drawing.Size(28, 30);
            this.textBox126.TabIndex = 271;
            // 
            // textBox127
            // 
            this.textBox127.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox127.Location = new System.Drawing.Point(513, 216);
            this.textBox127.Name = "textBox127";
            this.textBox127.Size = new System.Drawing.Size(28, 30);
            this.textBox127.TabIndex = 270;
            // 
            // textBox128
            // 
            this.textBox128.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox128.Location = new System.Drawing.Point(486, 216);
            this.textBox128.Name = "textBox128";
            this.textBox128.Size = new System.Drawing.Size(28, 30);
            this.textBox128.TabIndex = 269;
            // 
            // textBox129
            // 
            this.textBox129.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox129.Location = new System.Drawing.Point(461, 216);
            this.textBox129.Name = "textBox129";
            this.textBox129.Size = new System.Drawing.Size(28, 30);
            this.textBox129.TabIndex = 268;
            // 
            // textBox130
            // 
            this.textBox130.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox130.Location = new System.Drawing.Point(513, 188);
            this.textBox130.Name = "textBox130";
            this.textBox130.Size = new System.Drawing.Size(28, 30);
            this.textBox130.TabIndex = 267;
            // 
            // textBox131
            // 
            this.textBox131.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox131.Location = new System.Drawing.Point(486, 188);
            this.textBox131.Name = "textBox131";
            this.textBox131.Size = new System.Drawing.Size(28, 30);
            this.textBox131.TabIndex = 266;
            // 
            // textBox132
            // 
            this.textBox132.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox132.Location = new System.Drawing.Point(461, 188);
            this.textBox132.Name = "textBox132";
            this.textBox132.Size = new System.Drawing.Size(28, 30);
            this.textBox132.TabIndex = 265;
            // 
            // textBox133
            // 
            this.textBox133.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox133.Location = new System.Drawing.Point(513, 160);
            this.textBox133.Name = "textBox133";
            this.textBox133.Size = new System.Drawing.Size(28, 30);
            this.textBox133.TabIndex = 264;
            // 
            // textBox134
            // 
            this.textBox134.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox134.Location = new System.Drawing.Point(486, 160);
            this.textBox134.Name = "textBox134";
            this.textBox134.Size = new System.Drawing.Size(28, 30);
            this.textBox134.TabIndex = 263;
            // 
            // textBox135
            // 
            this.textBox135.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox135.Location = new System.Drawing.Point(461, 160);
            this.textBox135.Name = "textBox135";
            this.textBox135.Size = new System.Drawing.Size(28, 30);
            this.textBox135.TabIndex = 262;
            // 
            // textBox136
            // 
            this.textBox136.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox136.Location = new System.Drawing.Point(687, 120);
            this.textBox136.Name = "textBox136";
            this.textBox136.Size = new System.Drawing.Size(28, 30);
            this.textBox136.TabIndex = 261;
            // 
            // textBox137
            // 
            this.textBox137.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox137.Location = new System.Drawing.Point(662, 120);
            this.textBox137.Name = "textBox137";
            this.textBox137.Size = new System.Drawing.Size(28, 30);
            this.textBox137.TabIndex = 260;
            // 
            // textBox138
            // 
            this.textBox138.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox138.Location = new System.Drawing.Point(639, 120);
            this.textBox138.Name = "textBox138";
            this.textBox138.Size = new System.Drawing.Size(28, 30);
            this.textBox138.TabIndex = 259;
            // 
            // textBox139
            // 
            this.textBox139.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox139.Location = new System.Drawing.Point(687, 92);
            this.textBox139.Name = "textBox139";
            this.textBox139.Size = new System.Drawing.Size(28, 30);
            this.textBox139.TabIndex = 258;
            // 
            // textBox140
            // 
            this.textBox140.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox140.Location = new System.Drawing.Point(662, 92);
            this.textBox140.Name = "textBox140";
            this.textBox140.Size = new System.Drawing.Size(28, 30);
            this.textBox140.TabIndex = 257;
            // 
            // textBox141
            // 
            this.textBox141.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox141.Location = new System.Drawing.Point(639, 92);
            this.textBox141.Name = "textBox141";
            this.textBox141.Size = new System.Drawing.Size(28, 30);
            this.textBox141.TabIndex = 256;
            // 
            // textBox142
            // 
            this.textBox142.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox142.Location = new System.Drawing.Point(687, 64);
            this.textBox142.Name = "textBox142";
            this.textBox142.Size = new System.Drawing.Size(28, 30);
            this.textBox142.TabIndex = 255;
            // 
            // textBox143
            // 
            this.textBox143.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox143.Location = new System.Drawing.Point(662, 64);
            this.textBox143.Name = "textBox143";
            this.textBox143.Size = new System.Drawing.Size(28, 30);
            this.textBox143.TabIndex = 254;
            // 
            // textBox144
            // 
            this.textBox144.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox144.Location = new System.Drawing.Point(639, 64);
            this.textBox144.Name = "textBox144";
            this.textBox144.Size = new System.Drawing.Size(28, 30);
            this.textBox144.TabIndex = 253;
            // 
            // textBox145
            // 
            this.textBox145.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox145.Location = new System.Drawing.Point(549, 64);
            this.textBox145.Name = "textBox145";
            this.textBox145.Size = new System.Drawing.Size(28, 30);
            this.textBox145.TabIndex = 252;
            // 
            // textBox146
            // 
            this.textBox146.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox146.Location = new System.Drawing.Point(576, 64);
            this.textBox146.Name = "textBox146";
            this.textBox146.Size = new System.Drawing.Size(28, 30);
            this.textBox146.TabIndex = 251;
            // 
            // textBox147
            // 
            this.textBox147.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox147.Location = new System.Drawing.Point(603, 64);
            this.textBox147.Name = "textBox147";
            this.textBox147.Size = new System.Drawing.Size(28, 30);
            this.textBox147.TabIndex = 250;
            // 
            // textBox148
            // 
            this.textBox148.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox148.Location = new System.Drawing.Point(549, 120);
            this.textBox148.Name = "textBox148";
            this.textBox148.Size = new System.Drawing.Size(28, 30);
            this.textBox148.TabIndex = 249;
            // 
            // textBox149
            // 
            this.textBox149.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox149.Location = new System.Drawing.Point(549, 92);
            this.textBox149.Name = "textBox149";
            this.textBox149.Size = new System.Drawing.Size(28, 30);
            this.textBox149.TabIndex = 248;
            // 
            // textBox150
            // 
            this.textBox150.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox150.Location = new System.Drawing.Point(576, 92);
            this.textBox150.Name = "textBox150";
            this.textBox150.Size = new System.Drawing.Size(28, 30);
            this.textBox150.TabIndex = 247;
            this.textBox150.TextChanged += new System.EventHandler(this.textBox150_TextChanged);
            // 
            // textBox151
            // 
            this.textBox151.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox151.Location = new System.Drawing.Point(603, 92);
            this.textBox151.Name = "textBox151";
            this.textBox151.Size = new System.Drawing.Size(28, 30);
            this.textBox151.TabIndex = 246;
            // 
            // textBox152
            // 
            this.textBox152.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox152.Location = new System.Drawing.Point(576, 120);
            this.textBox152.Name = "textBox152";
            this.textBox152.Size = new System.Drawing.Size(28, 30);
            this.textBox152.TabIndex = 245;
            // 
            // textBox153
            // 
            this.textBox153.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox153.Location = new System.Drawing.Point(603, 120);
            this.textBox153.Name = "textBox153";
            this.textBox153.Size = new System.Drawing.Size(28, 30);
            this.textBox153.TabIndex = 244;
            // 
            // textBox154
            // 
            this.textBox154.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox154.Location = new System.Drawing.Point(513, 120);
            this.textBox154.Name = "textBox154";
            this.textBox154.Size = new System.Drawing.Size(28, 30);
            this.textBox154.TabIndex = 243;
            // 
            // textBox155
            // 
            this.textBox155.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox155.Location = new System.Drawing.Point(486, 120);
            this.textBox155.Name = "textBox155";
            this.textBox155.Size = new System.Drawing.Size(28, 30);
            this.textBox155.TabIndex = 242;
            // 
            // textBox156
            // 
            this.textBox156.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox156.Location = new System.Drawing.Point(461, 120);
            this.textBox156.Name = "textBox156";
            this.textBox156.Size = new System.Drawing.Size(28, 30);
            this.textBox156.TabIndex = 241;
            // 
            // textBox157
            // 
            this.textBox157.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox157.Location = new System.Drawing.Point(513, 92);
            this.textBox157.Name = "textBox157";
            this.textBox157.Size = new System.Drawing.Size(28, 30);
            this.textBox157.TabIndex = 240;
            // 
            // textBox158
            // 
            this.textBox158.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox158.Location = new System.Drawing.Point(486, 92);
            this.textBox158.Name = "textBox158";
            this.textBox158.Size = new System.Drawing.Size(28, 30);
            this.textBox158.TabIndex = 239;
            // 
            // textBox159
            // 
            this.textBox159.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox159.Location = new System.Drawing.Point(461, 92);
            this.textBox159.Name = "textBox159";
            this.textBox159.Size = new System.Drawing.Size(28, 30);
            this.textBox159.TabIndex = 238;
            // 
            // textBox160
            // 
            this.textBox160.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox160.Location = new System.Drawing.Point(513, 64);
            this.textBox160.Name = "textBox160";
            this.textBox160.Size = new System.Drawing.Size(28, 30);
            this.textBox160.TabIndex = 237;
            // 
            // textBox161
            // 
            this.textBox161.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox161.Location = new System.Drawing.Point(486, 64);
            this.textBox161.Name = "textBox161";
            this.textBox161.Size = new System.Drawing.Size(28, 30);
            this.textBox161.TabIndex = 236;
            // 
            // textBox162
            // 
            this.textBox162.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox162.Location = new System.Drawing.Point(461, 64);
            this.textBox162.Name = "textBox162";
            this.textBox162.Size = new System.Drawing.Size(28, 30);
            this.textBox162.TabIndex = 235;
            this.textBox162.TextChanged += new System.EventHandler(this.textBox162_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(98, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(244, 32);
            this.label1.TabIndex = 316;
            this.label1.Text = "Было загаданно: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(471, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(232, 32);
            this.label2.TabIndex = 317;
            this.label2.Text = "Что получилось:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(126, 367);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(248, 25);
            this.label3.TabIndex = 318;
            this.label3.Text = "Процент верных клеток: ";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(629, 367);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(145, 57);
            this.button1.TabIndex = 319;
            this.button1.Text = "Играть еще!";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(477, 367);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(147, 57);
            this.button2.TabIndex = 320;
            this.button2.Text = "Показать";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(389, 375);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 17);
            this.label4.TabIndex = 321;
            this.label4.Text = "label4";
            this.label4.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(263, 400);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 24);
            this.label5.TabIndex = 322;
            this.label5.Text = "Ваш опыт:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(389, 407);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 17);
            this.label6.TabIndex = 323;
            this.label6.Text = "label6";
            this.label6.Visible = false;
            // 
            // trueSudoku
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox82);
            this.Controls.Add(this.textBox83);
            this.Controls.Add(this.textBox84);
            this.Controls.Add(this.textBox85);
            this.Controls.Add(this.textBox86);
            this.Controls.Add(this.textBox87);
            this.Controls.Add(this.textBox88);
            this.Controls.Add(this.textBox89);
            this.Controls.Add(this.textBox90);
            this.Controls.Add(this.textBox91);
            this.Controls.Add(this.textBox92);
            this.Controls.Add(this.textBox93);
            this.Controls.Add(this.textBox94);
            this.Controls.Add(this.textBox95);
            this.Controls.Add(this.textBox96);
            this.Controls.Add(this.textBox97);
            this.Controls.Add(this.textBox98);
            this.Controls.Add(this.textBox99);
            this.Controls.Add(this.textBox100);
            this.Controls.Add(this.textBox101);
            this.Controls.Add(this.textBox102);
            this.Controls.Add(this.textBox103);
            this.Controls.Add(this.textBox104);
            this.Controls.Add(this.textBox105);
            this.Controls.Add(this.textBox106);
            this.Controls.Add(this.textBox107);
            this.Controls.Add(this.textBox108);
            this.Controls.Add(this.textBox109);
            this.Controls.Add(this.textBox110);
            this.Controls.Add(this.textBox111);
            this.Controls.Add(this.textBox112);
            this.Controls.Add(this.textBox113);
            this.Controls.Add(this.textBox114);
            this.Controls.Add(this.textBox115);
            this.Controls.Add(this.textBox116);
            this.Controls.Add(this.textBox117);
            this.Controls.Add(this.textBox118);
            this.Controls.Add(this.textBox119);
            this.Controls.Add(this.textBox120);
            this.Controls.Add(this.textBox121);
            this.Controls.Add(this.textBox122);
            this.Controls.Add(this.textBox123);
            this.Controls.Add(this.textBox124);
            this.Controls.Add(this.textBox125);
            this.Controls.Add(this.textBox126);
            this.Controls.Add(this.textBox127);
            this.Controls.Add(this.textBox128);
            this.Controls.Add(this.textBox129);
            this.Controls.Add(this.textBox130);
            this.Controls.Add(this.textBox131);
            this.Controls.Add(this.textBox132);
            this.Controls.Add(this.textBox133);
            this.Controls.Add(this.textBox134);
            this.Controls.Add(this.textBox135);
            this.Controls.Add(this.textBox136);
            this.Controls.Add(this.textBox137);
            this.Controls.Add(this.textBox138);
            this.Controls.Add(this.textBox139);
            this.Controls.Add(this.textBox140);
            this.Controls.Add(this.textBox141);
            this.Controls.Add(this.textBox142);
            this.Controls.Add(this.textBox143);
            this.Controls.Add(this.textBox144);
            this.Controls.Add(this.textBox145);
            this.Controls.Add(this.textBox146);
            this.Controls.Add(this.textBox147);
            this.Controls.Add(this.textBox148);
            this.Controls.Add(this.textBox149);
            this.Controls.Add(this.textBox150);
            this.Controls.Add(this.textBox151);
            this.Controls.Add(this.textBox152);
            this.Controls.Add(this.textBox153);
            this.Controls.Add(this.textBox154);
            this.Controls.Add(this.textBox155);
            this.Controls.Add(this.textBox156);
            this.Controls.Add(this.textBox157);
            this.Controls.Add(this.textBox158);
            this.Controls.Add(this.textBox159);
            this.Controls.Add(this.textBox160);
            this.Controls.Add(this.textBox161);
            this.Controls.Add(this.textBox162);
            this.Controls.Add(this.textBox73);
            this.Controls.Add(this.textBox74);
            this.Controls.Add(this.textBox75);
            this.Controls.Add(this.textBox76);
            this.Controls.Add(this.textBox77);
            this.Controls.Add(this.textBox78);
            this.Controls.Add(this.textBox79);
            this.Controls.Add(this.textBox80);
            this.Controls.Add(this.textBox81);
            this.Controls.Add(this.textBox64);
            this.Controls.Add(this.textBox65);
            this.Controls.Add(this.textBox66);
            this.Controls.Add(this.textBox67);
            this.Controls.Add(this.textBox68);
            this.Controls.Add(this.textBox69);
            this.Controls.Add(this.textBox70);
            this.Controls.Add(this.textBox71);
            this.Controls.Add(this.textBox72);
            this.Controls.Add(this.textBox55);
            this.Controls.Add(this.textBox56);
            this.Controls.Add(this.textBox57);
            this.Controls.Add(this.textBox58);
            this.Controls.Add(this.textBox59);
            this.Controls.Add(this.textBox60);
            this.Controls.Add(this.textBox61);
            this.Controls.Add(this.textBox62);
            this.Controls.Add(this.textBox63);
            this.Controls.Add(this.textBox46);
            this.Controls.Add(this.textBox47);
            this.Controls.Add(this.textBox48);
            this.Controls.Add(this.textBox49);
            this.Controls.Add(this.textBox50);
            this.Controls.Add(this.textBox51);
            this.Controls.Add(this.textBox52);
            this.Controls.Add(this.textBox53);
            this.Controls.Add(this.textBox54);
            this.Controls.Add(this.textBox37);
            this.Controls.Add(this.textBox38);
            this.Controls.Add(this.textBox39);
            this.Controls.Add(this.textBox40);
            this.Controls.Add(this.textBox41);
            this.Controls.Add(this.textBox42);
            this.Controls.Add(this.textBox43);
            this.Controls.Add(this.textBox44);
            this.Controls.Add(this.textBox45);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.textBox31);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.textBox33);
            this.Controls.Add(this.textBox34);
            this.Controls.Add(this.textBox35);
            this.Controls.Add(this.textBox36);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Name = "trueSudoku";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Проверка";
            this.Load += new System.EventHandler(this.trueSudoku_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.TextBox textBox85;
        private System.Windows.Forms.TextBox textBox86;
        private System.Windows.Forms.TextBox textBox87;
        private System.Windows.Forms.TextBox textBox88;
        private System.Windows.Forms.TextBox textBox89;
        private System.Windows.Forms.TextBox textBox90;
        private System.Windows.Forms.TextBox textBox91;
        private System.Windows.Forms.TextBox textBox92;
        private System.Windows.Forms.TextBox textBox93;
        private System.Windows.Forms.TextBox textBox94;
        private System.Windows.Forms.TextBox textBox95;
        private System.Windows.Forms.TextBox textBox96;
        private System.Windows.Forms.TextBox textBox97;
        private System.Windows.Forms.TextBox textBox98;
        private System.Windows.Forms.TextBox textBox99;
        private System.Windows.Forms.TextBox textBox100;
        private System.Windows.Forms.TextBox textBox101;
        private System.Windows.Forms.TextBox textBox102;
        private System.Windows.Forms.TextBox textBox103;
        private System.Windows.Forms.TextBox textBox104;
        private System.Windows.Forms.TextBox textBox105;
        private System.Windows.Forms.TextBox textBox106;
        private System.Windows.Forms.TextBox textBox107;
        private System.Windows.Forms.TextBox textBox108;
        private System.Windows.Forms.TextBox textBox109;
        private System.Windows.Forms.TextBox textBox110;
        private System.Windows.Forms.TextBox textBox111;
        private System.Windows.Forms.TextBox textBox112;
        private System.Windows.Forms.TextBox textBox113;
        private System.Windows.Forms.TextBox textBox114;
        private System.Windows.Forms.TextBox textBox115;
        private System.Windows.Forms.TextBox textBox116;
        private System.Windows.Forms.TextBox textBox117;
        private System.Windows.Forms.TextBox textBox118;
        private System.Windows.Forms.TextBox textBox119;
        private System.Windows.Forms.TextBox textBox120;
        private System.Windows.Forms.TextBox textBox121;
        private System.Windows.Forms.TextBox textBox122;
        private System.Windows.Forms.TextBox textBox123;
        private System.Windows.Forms.TextBox textBox124;
        private System.Windows.Forms.TextBox textBox125;
        private System.Windows.Forms.TextBox textBox126;
        private System.Windows.Forms.TextBox textBox127;
        private System.Windows.Forms.TextBox textBox128;
        private System.Windows.Forms.TextBox textBox129;
        private System.Windows.Forms.TextBox textBox130;
        private System.Windows.Forms.TextBox textBox131;
        private System.Windows.Forms.TextBox textBox132;
        private System.Windows.Forms.TextBox textBox133;
        private System.Windows.Forms.TextBox textBox134;
        private System.Windows.Forms.TextBox textBox135;
        private System.Windows.Forms.TextBox textBox136;
        private System.Windows.Forms.TextBox textBox137;
        private System.Windows.Forms.TextBox textBox138;
        private System.Windows.Forms.TextBox textBox139;
        private System.Windows.Forms.TextBox textBox140;
        private System.Windows.Forms.TextBox textBox141;
        private System.Windows.Forms.TextBox textBox142;
        private System.Windows.Forms.TextBox textBox143;
        private System.Windows.Forms.TextBox textBox144;
        private System.Windows.Forms.TextBox textBox145;
        private System.Windows.Forms.TextBox textBox146;
        private System.Windows.Forms.TextBox textBox147;
        private System.Windows.Forms.TextBox textBox148;
        private System.Windows.Forms.TextBox textBox149;
        private System.Windows.Forms.TextBox textBox150;
        private System.Windows.Forms.TextBox textBox151;
        private System.Windows.Forms.TextBox textBox152;
        private System.Windows.Forms.TextBox textBox153;
        private System.Windows.Forms.TextBox textBox154;
        private System.Windows.Forms.TextBox textBox155;
        private System.Windows.Forms.TextBox textBox156;
        private System.Windows.Forms.TextBox textBox157;
        private System.Windows.Forms.TextBox textBox158;
        private System.Windows.Forms.TextBox textBox159;
        private System.Windows.Forms.TextBox textBox160;
        private System.Windows.Forms.TextBox textBox161;
        private System.Windows.Forms.TextBox textBox162;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        public System.Windows.Forms.TextBox textBox73;
        public System.Windows.Forms.TextBox textBox74;
        public System.Windows.Forms.TextBox textBox75;
        public System.Windows.Forms.TextBox textBox76;
        public System.Windows.Forms.TextBox textBox77;
        public System.Windows.Forms.TextBox textBox78;
        public System.Windows.Forms.TextBox textBox79;
        public System.Windows.Forms.TextBox textBox80;
        public System.Windows.Forms.TextBox textBox81;
        public System.Windows.Forms.TextBox textBox64;
        public System.Windows.Forms.TextBox textBox65;
        public System.Windows.Forms.TextBox textBox66;
        public System.Windows.Forms.TextBox textBox67;
        public System.Windows.Forms.TextBox textBox68;
        public System.Windows.Forms.TextBox textBox69;
        public System.Windows.Forms.TextBox textBox70;
        public System.Windows.Forms.TextBox textBox71;
        public System.Windows.Forms.TextBox textBox72;
        public System.Windows.Forms.TextBox textBox55;
        public System.Windows.Forms.TextBox textBox56;
        public System.Windows.Forms.TextBox textBox57;
        public System.Windows.Forms.TextBox textBox58;
        public System.Windows.Forms.TextBox textBox59;
        public System.Windows.Forms.TextBox textBox60;
        public System.Windows.Forms.TextBox textBox61;
        public System.Windows.Forms.TextBox textBox62;
        public System.Windows.Forms.TextBox textBox63;
        public System.Windows.Forms.TextBox textBox46;
        public System.Windows.Forms.TextBox textBox47;
        public System.Windows.Forms.TextBox textBox48;
        public System.Windows.Forms.TextBox textBox49;
        public System.Windows.Forms.TextBox textBox50;
        public System.Windows.Forms.TextBox textBox51;
        public System.Windows.Forms.TextBox textBox52;
        public System.Windows.Forms.TextBox textBox53;
        public System.Windows.Forms.TextBox textBox54;
        public System.Windows.Forms.TextBox textBox37;
        public System.Windows.Forms.TextBox textBox38;
        public System.Windows.Forms.TextBox textBox39;
        public System.Windows.Forms.TextBox textBox40;
        public System.Windows.Forms.TextBox textBox41;
        public System.Windows.Forms.TextBox textBox42;
        public System.Windows.Forms.TextBox textBox43;
        public System.Windows.Forms.TextBox textBox44;
        public System.Windows.Forms.TextBox textBox45;
        public System.Windows.Forms.TextBox textBox28;
        public System.Windows.Forms.TextBox textBox29;
        public System.Windows.Forms.TextBox textBox30;
        public System.Windows.Forms.TextBox textBox31;
        public System.Windows.Forms.TextBox textBox32;
        public System.Windows.Forms.TextBox textBox33;
        public System.Windows.Forms.TextBox textBox34;
        public System.Windows.Forms.TextBox textBox35;
        public System.Windows.Forms.TextBox textBox36;
        public System.Windows.Forms.TextBox textBox19;
        public System.Windows.Forms.TextBox textBox20;
        public System.Windows.Forms.TextBox textBox21;
        public System.Windows.Forms.TextBox textBox22;
        public System.Windows.Forms.TextBox textBox23;
        public System.Windows.Forms.TextBox textBox24;
        public System.Windows.Forms.TextBox textBox25;
        public System.Windows.Forms.TextBox textBox26;
        public System.Windows.Forms.TextBox textBox27;
        public System.Windows.Forms.TextBox textBox10;
        public System.Windows.Forms.TextBox textBox11;
        public System.Windows.Forms.TextBox textBox12;
        public System.Windows.Forms.TextBox textBox13;
        public System.Windows.Forms.TextBox textBox14;
        public System.Windows.Forms.TextBox textBox15;
        public System.Windows.Forms.TextBox textBox16;
        public System.Windows.Forms.TextBox textBox17;
        public System.Windows.Forms.TextBox textBox18;
        public System.Windows.Forms.TextBox textBox9;
        public System.Windows.Forms.TextBox textBox8;
        public System.Windows.Forms.TextBox textBox7;
        public System.Windows.Forms.TextBox textBox6;
        public System.Windows.Forms.TextBox textBox5;
        public System.Windows.Forms.TextBox textBox4;
        public System.Windows.Forms.TextBox textBox3;
        public System.Windows.Forms.TextBox textBox2;
        public System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}