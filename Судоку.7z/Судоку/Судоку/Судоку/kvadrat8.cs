﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Судоку
{
    public class kvadrat8
    {
        public static void Resh(string[,] sudoku, bool LogFlag)
        {
            if(LogFlag) File.AppendAllText(Form1.Folder, "Смотрим восьмой квадрат \r\n");
            Stack<string> stackPossibleValues = new Stack<string>();
            int i1 = 0, j1 = 0, Tatar = 0;
            for (int n = 1; n <= 9; n++)
            {
                for (int i = 6; i < 9; i++)
                {
                    for (int j = 3; j < 6; j++)
                    {
                        if ((sudoku[i, j] == "0") && (Stroka(sudoku, n, i) == true)
                            && (Stolbec(sudoku, n, j) == true) && (Kv(sudoku, n, i, j) == true))
                        {
                            stackPossibleValues.Push(Convert.ToString(n));
                            i1 = i;
                            j1 = j;
                        }
                    }
                }
                if (stackPossibleValues.Count == 1)
                {
                    if (LogFlag)
                    {
                        string Log = "Число " + Convert.ToString(n) + " может стоять только в ячейке " + "(" + Convert.ToString(i1) + "," + Convert.ToString(j1) + ")" + ", значит смело его ставим в ячейку \r\n";
                        File.AppendAllText(Form1.Folder, Log);
                    }
                    Tatar = 1;
                    sudoku[i1, j1] = stackPossibleValues.Pop();
                }
                stackPossibleValues.Clear();
            }
            if (Tatar == 0 && LogFlag) File.AppendAllText(Form1.Folder, "Никаких зацепок, иду дальше \r\n");
            kvadrat9.Resh(sudoku, LogFlag);
        }
        public static bool Stroka(string[,] array, int number, int k)
        {
            bool chi = true;
            for (int j = 0; j < 9; j++)
            {
                if (Convert.ToInt32(array[k, j]) == number)
                {
                    chi = false;
                    break;
                }
            }
            return chi;
        }
        public static bool Stolbec(string[,] array, int number, int k)
        {
            bool chi = true;
            for (int i = 0; i < 9; i++)
            {
                if (Convert.ToInt32(array[i, k]) == number)
                {
                    chi = false;
                    break;
                }
            }
            return chi;
        }
        public static bool Kv(string[,] array, int number, int k, int l)
        {
            bool chi = true;
            for (int i = 6; i < 9; i++)
            {
                for (int j = 3; j < 6; j++)
                {
                    if (Convert.ToInt32(array[i, j]) == number)
                    {
                        chi = false;
                    }
                }
            }
            return chi;
        }
    }
}
