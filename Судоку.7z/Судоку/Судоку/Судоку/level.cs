﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Судоку
{
    class level
    {
        public static int Uroven (int exp)
        {
            int Lev = 1;
            if (exp >= 200 && exp < 400)
                Lev = 2;
            if (exp >= 400 && exp < 600)
                Lev = 3;
            if (exp >= 600 && exp < 800)
                Lev = 4;
            if (exp >= 800 && exp < 1000)
                Lev = 5;
            if (exp >= 1000 && exp < 1200)
                Lev = 6;
            if (exp >= 1200)
                Lev = 7;
            return Lev;
        }
    }
}
