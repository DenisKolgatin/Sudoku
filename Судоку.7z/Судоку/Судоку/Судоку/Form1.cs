﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Судоку
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        public static int CountS = 0;
        public static int CountRightS = 0;
        public static string Folder = "d:\\sudokuLOG.txt";
        public void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                FolderBrowserDialog FBD = new FolderBrowserDialog();
                if (FBD.ShowDialog() == DialogResult.OK)
                {
                    Folder = FBD.SelectedPath + "sudokuLOG.txt";
                }
                File.Delete(Folder); //удаление файла 
                File.AppendAllText(Folder, "Создан новый Судоку \r\n"); //допишет текст в конец файла
                button4.Visible = true;
            }
            CountS++;
            string[,] sudoku = new string[9, 9];
            //Читаем с форм и заносим в массив
            //Первый квадрат
            sudoku[0, 0] = textBox1.Text;
            sudoku[0, 1] = textBox2.Text;
            sudoku[0, 2] = textBox3.Text;
            sudoku[1, 0] = textBox4.Text;
            sudoku[1, 1] = textBox5.Text;
            sudoku[1, 2] = textBox6.Text;
            sudoku[2, 0] = textBox7.Text;
            sudoku[2, 1] = textBox8.Text;
            sudoku[2, 2] = textBox9.Text;
            //Второй квадрат
            sudoku[0, 3] = textBox10.Text;
            sudoku[0, 4] = textBox11.Text;
            sudoku[0, 5] = textBox12.Text;
            sudoku[1, 3] = textBox14.Text;
            sudoku[1, 4] = textBox15.Text;
            sudoku[1, 5] = textBox16.Text;
            sudoku[2, 3] = textBox13.Text;
            sudoku[2, 4] = textBox17.Text;
            sudoku[2, 5] = textBox18.Text;
            //Третий квадрат
            sudoku[0, 6] = textBox27.Text;
            sudoku[0, 7] = textBox26.Text;
            sudoku[0, 8] = textBox25.Text;
            sudoku[1, 6] = textBox24.Text;
            sudoku[1, 7] = textBox23.Text;
            sudoku[1, 8] = textBox22.Text;
            sudoku[2, 6] = textBox21.Text;
            sudoku[2, 7] = textBox20.Text;
            sudoku[2, 8] = textBox19.Text;
            //Четвертый квадрат
            sudoku[3, 0] = textBox36.Text;
            sudoku[3, 1] = textBox35.Text;
            sudoku[3, 2] = textBox34.Text;
            sudoku[4, 0] = textBox33.Text;
            sudoku[4, 1] = textBox32.Text;
            sudoku[4, 2] = textBox31.Text;
            sudoku[5, 0] = textBox30.Text;
            sudoku[5, 1] = textBox29.Text;
            sudoku[5, 2] = textBox28.Text;
            //Пятый квадрат
            sudoku[3, 3] = textBox45.Text;
            sudoku[3, 4] = textBox44.Text;
            sudoku[3, 5] = textBox43.Text;
            sudoku[4, 3] = textBox42.Text;
            sudoku[4, 4] = textBox41.Text;
            sudoku[4, 5] = textBox40.Text;
            sudoku[5, 3] = textBox39.Text;
            sudoku[5, 4] = textBox38.Text;
            sudoku[5, 5] = textBox37.Text;
            //Шестой квадрат
            sudoku[3, 6] = textBox54.Text;
            sudoku[3, 7] = textBox53.Text;
            sudoku[3, 8] = textBox52.Text;
            sudoku[4, 6] = textBox51.Text;
            sudoku[4, 7] = textBox50.Text;
            sudoku[4, 8] = textBox49.Text;
            sudoku[5, 6] = textBox48.Text;
            sudoku[5, 7] = textBox47.Text;
            sudoku[5, 8] = textBox46.Text;
            //Седьмой квадрат
            sudoku[6, 0] = textBox63.Text;
            sudoku[6, 1] = textBox62.Text;
            sudoku[6, 2] = textBox61.Text;
            sudoku[7, 0] = textBox60.Text;
            sudoku[7, 1] = textBox59.Text;
            sudoku[7, 2] = textBox58.Text;
            sudoku[8, 0] = textBox57.Text;
            sudoku[8, 1] = textBox56.Text;
            sudoku[8, 2] = textBox55.Text;
            //Восьмой квадрат
            sudoku[6, 3] = textBox72.Text;
            sudoku[6, 4] = textBox71.Text;
            sudoku[6, 5] = textBox70.Text;
            sudoku[7, 3] = textBox69.Text;
            sudoku[7, 4] = textBox68.Text;
            sudoku[7, 5] = textBox67.Text;
            sudoku[8, 3] = textBox66.Text;
            sudoku[8, 4] = textBox65.Text;
            sudoku[8, 5] = textBox64.Text;
            //Девятый квадрат
            sudoku[6, 6] = textBox81.Text;
            sudoku[6, 7] = textBox80.Text;
            sudoku[6, 8] = textBox79.Text;
            sudoku[7, 6] = textBox78.Text;
            sudoku[7, 7] = textBox77.Text;
            sudoku[7, 8] = textBox76.Text;
            sudoku[8, 6] = textBox75.Text;
            sudoku[8, 7] = textBox74.Text;
            sudoku[8, 8] = textBox73.Text;

            int T = 0; //счетчик выполнения цикла
            Zamena(sudoku);
            label5.Visible = true;
            while (Proverka(sudoku) == false && T<21)
            {
                if (checkBox1.Checked)
                {
                    kvadrat1.Resh(sudoku, true);
                    if (T > 0 && T < 20) File.AppendAllText(Folder, "Все еще остались пустые ячейки, запускаю программу заново \r\n");

                }
                else kvadrat1.Resh(sudoku, false);
                T++;
                label5.Text = Convert.ToString(T);
            }
            if (checkBox1.Checked)
            {
                File.AppendAllText(Folder, "Здесь наши полномочия все, " +
                "завершаю программу и вывожу результат \r\n");
            }
            AntiZamena(sudoku);
            //Возвращаем назад в формы
            //Первый квадрат

            textBox1.Text = sudoku[0, 0];
            textBox2.Text = sudoku[0, 1];
            textBox3.Text = sudoku[0, 2];
            textBox4.Text = sudoku[1, 0];
            textBox5.Text = sudoku[1, 1];
            textBox6.Text = sudoku[1, 2];
            textBox7.Text = sudoku[2, 0];
            textBox8.Text = sudoku[2, 1];
            textBox9.Text = sudoku[2, 2];
            //Второй квадрат
            textBox10.Text = sudoku[0, 3];
            textBox11.Text = sudoku[0, 4];
            textBox12.Text = sudoku[0, 5];
            textBox14.Text = sudoku[1, 3];
            textBox15.Text = sudoku[1, 4];
            textBox16.Text = sudoku[1, 5];
            textBox13.Text = sudoku[2, 3];
            textBox17.Text = sudoku[2, 4];
            textBox18.Text = sudoku[2, 5];
            //Третий квадрат
            textBox27.Text = sudoku[0, 6];
            textBox26.Text = sudoku[0, 7];
            textBox25.Text = sudoku[0, 8];
            textBox24.Text = sudoku[1, 6];
            textBox23.Text = sudoku[1, 7];
            textBox22.Text = sudoku[1, 8];
            textBox21.Text = sudoku[2, 6];
            textBox20.Text = sudoku[2, 7];
            textBox19.Text = sudoku[2, 8];
            //Четвертый квадрат
            textBox36.Text = sudoku[3, 0];
            textBox35.Text = sudoku[3, 1];
            textBox34.Text = sudoku[3, 2];
            textBox33.Text = sudoku[4, 0];
            textBox32.Text = sudoku[4, 1];
            textBox31.Text = sudoku[4, 2];
            textBox30.Text = sudoku[5, 0];
            textBox29.Text = sudoku[5, 1];
            textBox28.Text = sudoku[5, 2];
            //Пятый квадрат
            textBox45.Text = sudoku[3, 3];
            textBox44.Text = sudoku[3, 4];
            textBox43.Text = sudoku[3, 5];
            textBox42.Text = sudoku[4, 3];
            textBox41.Text = sudoku[4, 4];
            textBox40.Text = sudoku[4, 5];
            textBox39.Text = sudoku[5, 3];
            textBox38.Text = sudoku[5, 4];
            textBox37.Text = sudoku[5, 5];
            //Шестой квадрат
            textBox54.Text = sudoku[3, 6];
            textBox53.Text = sudoku[3, 7];
            textBox52.Text = sudoku[3, 8];
            textBox51.Text = sudoku[4, 6];
            textBox50.Text = sudoku[4, 7];
            textBox49.Text = sudoku[4, 8];
            textBox48.Text = sudoku[5, 6];
            textBox47.Text = sudoku[5, 7];
            textBox46.Text = sudoku[5, 8];
            //Седьмой квадрат
            textBox63.Text = sudoku[6, 0];
            textBox62.Text = sudoku[6, 1];
            textBox61.Text = sudoku[6, 2];
            textBox60.Text = sudoku[7, 0];
            textBox59.Text = sudoku[7, 1];
            textBox58.Text = sudoku[7, 2];
            textBox57.Text = sudoku[8, 0];
            textBox56.Text = sudoku[8, 1];
            textBox55.Text = sudoku[8, 2];
            //Восьмой квадрат
            textBox72.Text = sudoku[6, 3];
            textBox71.Text = sudoku[6, 4];
            textBox70.Text = sudoku[6, 5];
            textBox69.Text = sudoku[7, 3];
            textBox68.Text = sudoku[7, 4];
            textBox67.Text = sudoku[7, 5];
            textBox66.Text = sudoku[8, 3];
            textBox65.Text = sudoku[8, 4];
            textBox64.Text = sudoku[8, 5];
            //Девятый квадрат
            textBox81.Text = sudoku[6, 6];
            textBox80.Text = sudoku[6, 7];
            textBox79.Text = sudoku[6, 8];
            textBox78.Text = sudoku[7, 6];
            textBox77.Text = sudoku[7, 7];
            textBox76.Text = sudoku[7, 8];
            textBox75.Text = sudoku[8, 6];
            textBox74.Text = sudoku[8, 7];
            textBox73.Text = sudoku[8, 8];
        }


        public static bool Proverka(string[,] sudoku)
        {
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (sudoku[i, j] == "0") return false;
                }
            }
            return true;
        }

        //Заменяем все " " на нули
        public static void Zamena(string[,] array)
        {
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (array[i, j] == "") array[i, j] = "0";
                }
            }
        }

        //Заменяем все нули на " "
        public static void AntiZamena(string[,] array)
        {
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (array[i, j] == "0") array[i, j] = "";
                }
            }
        }


        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        public void Label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            button4.Visible = false;
            label5.Visible = false;
            textBox1.Text = null;
            textBox2.Text = null;
            textBox3.Text = null;
            textBox4.Text = null;
            textBox5.Text = null;
            textBox6.Text = null;
            textBox7.Text = null;
            textBox8.Text = null;
            textBox9.Text = null;
            //Второй квадрат
            textBox10.Text = null;
            textBox11.Text = null;
            textBox12.Text = null;
            textBox14.Text = null;
            textBox15.Text = null;
            textBox16.Text = null;
            textBox13.Text = null;
            textBox17.Text = null;
            textBox18.Text = null;
            //Третий квадрат
            textBox27.Text = null;
            textBox26.Text = null;
            textBox25.Text = null;
            textBox24.Text = null;
            textBox23.Text = null;
            textBox22.Text = null;
            textBox21.Text = null;
            textBox20.Text = null;
            textBox19.Text = null;
            //Четвертый квадрат
            textBox36.Text = null;
            textBox35.Text = null;
            textBox34.Text = null;
            textBox33.Text = null;
            textBox32.Text = null;
            textBox31.Text = null;
            textBox30.Text = null;
            textBox29.Text = null;
            textBox28.Text = null;
            //Пятый квадрат
            textBox45.Text = null;
            textBox44.Text = null;
            textBox43.Text = null;
            textBox42.Text = null;
            textBox41.Text = null;
            textBox40.Text = null;
            textBox39.Text = null;
            textBox38.Text = null;
            textBox37.Text = null;
            //Шестой квадрат
            textBox54.Text = null;
            textBox53.Text = null;
            textBox52.Text = null;
            textBox51.Text = null;
            textBox50.Text = null;
            textBox49.Text = null;
            textBox48.Text = null;
            textBox47.Text = null;
            textBox46.Text = null;
            //Седьмой квадрат
            textBox63.Text = null;
            textBox62.Text = null;
            textBox61.Text = null;
            textBox60.Text = null;
            textBox59.Text = null;
            textBox58.Text = null;
            textBox57.Text = null;
            textBox56.Text = null;
            textBox55.Text = null;
            //Восьмой квадрат
            textBox72.Text = null;
            textBox71.Text = null;
            textBox70.Text = null;
            textBox69.Text = null;
            textBox68.Text = null;
            textBox67.Text = null;
            textBox66.Text = null;
            textBox65.Text = null;
            textBox64.Text = null;
            //Девятый квадрат
            textBox81.Text = null;
            textBox80.Text = null;
            textBox79.Text = null;
            textBox78.Text = null;
            textBox77.Text = null;
            textBox76.Text = null;
            textBox75.Text = null;
            textBox74.Text = null;
            textBox73.Text = null;
        }

        private void textBox35_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox76_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Hide();
            Start frm1 = new Start();
            frm1.ShowDialog();
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string path = Folder;
            Process.Start(path);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
