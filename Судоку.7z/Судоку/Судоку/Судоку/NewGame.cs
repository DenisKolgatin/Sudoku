﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;
using Timer = System.Timers.Timer;

namespace Судоку
{
    public partial class NewGame : Form
    {
        public NewGame()
        {
            InitializeComponent();
            if (level.Uroven(Expirience) == 7) label7.Text = "Вы император судоку!";
            else label7.Text = Convert.ToString(level.Uroven(Expirience));
            label12.Text = Convert.ToString(Expirience);


        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hide();
            Start frm1 = new Start();
            frm1.ShowDialog();
            Close();
        }
        public static int Expirience;
        public string[,] sudoku = new string[9, 9]; //оригинальный вариант
        public string[,] udokus = new string[9, 9]; //закодированный
        public string[,] SuDo = new string[9, 9]; //для проверки закодированного
        private void button2_Click(object sender, EventArgs e)
        {
            Chteniye(udokus);
            Hide();
            trueSudoku trueSudoku = new trueSudoku();
            trueSudoku.Owner = this;
            trueSudoku.ShowDialog();
            Close();
        }
        public void Chteniye(string[,] sudoku)
        {
            //Первый квадрат
            sudoku[0, 0] = textBox1.Text;
            sudoku[0, 1] = textBox2.Text;
            sudoku[0, 2] = textBox3.Text;
            sudoku[1, 0] = textBox4.Text;
            sudoku[1, 1] = textBox5.Text;
            sudoku[1, 2] = textBox6.Text;
            sudoku[2, 0] = textBox7.Text;
            sudoku[2, 1] = textBox8.Text;
            sudoku[2, 2] = textBox9.Text;
            //Второй квадрат
            sudoku[0, 3] = textBox10.Text;
            sudoku[0, 4] = textBox11.Text;
            sudoku[0, 5] = textBox12.Text;
            sudoku[1, 3] = textBox14.Text;
            sudoku[1, 4] = textBox15.Text;
            sudoku[1, 5] = textBox16.Text;
            sudoku[2, 3] = textBox13.Text;
            sudoku[2, 4] = textBox17.Text;
            sudoku[2, 5] = textBox18.Text;
            //Третий квадрат
            sudoku[0, 6] = textBox27.Text;
            sudoku[0, 7] = textBox26.Text;
            sudoku[0, 8] = textBox25.Text;
            sudoku[1, 6] = textBox24.Text;
            sudoku[1, 7] = textBox23.Text;
            sudoku[1, 8] = textBox22.Text;
            sudoku[2, 6] = textBox21.Text;
            sudoku[2, 7] = textBox20.Text;
            sudoku[2, 8] = textBox19.Text;
            //Четвертый квадрат
            sudoku[3, 0] = textBox36.Text;
            sudoku[3, 1] = textBox35.Text;
            sudoku[3, 2] = textBox34.Text;
            sudoku[4, 0] = textBox33.Text;
            sudoku[4, 1] = textBox32.Text;
            sudoku[4, 2] = textBox31.Text;
            sudoku[5, 0] = textBox30.Text;
            sudoku[5, 1] = textBox29.Text;
            sudoku[5, 2] = textBox28.Text;
            //Пятый квадрат
            sudoku[3, 3] = textBox45.Text;
            sudoku[3, 4] = textBox44.Text;
            sudoku[3, 5] = textBox43.Text;
            sudoku[4, 3] = textBox42.Text;
            sudoku[4, 4] = textBox41.Text;
            sudoku[4, 5] = textBox40.Text;
            sudoku[5, 3] = textBox39.Text;
            sudoku[5, 4] = textBox38.Text;
            sudoku[5, 5] = textBox37.Text;
            //Шестой квадрат
            sudoku[3, 6] = textBox54.Text;
            sudoku[3, 7] = textBox53.Text;
            sudoku[3, 8] = textBox52.Text;
            sudoku[4, 6] = textBox51.Text;
            sudoku[4, 7] = textBox50.Text;
            sudoku[4, 8] = textBox49.Text;
            sudoku[5, 6] = textBox48.Text;
            sudoku[5, 7] = textBox47.Text;
            sudoku[5, 8] = textBox46.Text;
            //Седьмой квадрат
            sudoku[6, 0] = textBox63.Text;
            sudoku[6, 1] = textBox62.Text;
            sudoku[6, 2] = textBox61.Text;
            sudoku[7, 0] = textBox60.Text;
            sudoku[7, 1] = textBox59.Text;
            sudoku[7, 2] = textBox58.Text;
            sudoku[8, 0] = textBox57.Text;
            sudoku[8, 1] = textBox56.Text;
            sudoku[8, 2] = textBox55.Text;
            //Восьмой квадрат
            sudoku[6, 3] = textBox72.Text;
            sudoku[6, 4] = textBox71.Text;
            sudoku[6, 5] = textBox70.Text;
            sudoku[7, 3] = textBox69.Text;
            sudoku[7, 4] = textBox68.Text;
            sudoku[7, 5] = textBox67.Text;
            sudoku[8, 3] = textBox66.Text;
            sudoku[8, 4] = textBox65.Text;
            sudoku[8, 5] = textBox64.Text;
            //Девятый квадрат
            sudoku[6, 6] = textBox81.Text;
            sudoku[6, 7] = textBox80.Text;
            sudoku[6, 8] = textBox79.Text;
            sudoku[7, 6] = textBox78.Text;
            sudoku[7, 7] = textBox77.Text;
            sudoku[7, 8] = textBox76.Text;
            sudoku[8, 6] = textBox75.Text;
            sudoku[8, 7] = textBox74.Text;
            sudoku[8, 8] = textBox73.Text;
        }
        public void Zapis(string[,] sudoku)
        {
            textBox1.Text = sudoku[0, 0];
            textBox2.Text = sudoku[0, 1];
            textBox3.Text = sudoku[0, 2];
            textBox4.Text = sudoku[1, 0];
            textBox5.Text = sudoku[1, 1];
            textBox6.Text = sudoku[1, 2];
            textBox7.Text = sudoku[2, 0];
            textBox8.Text = sudoku[2, 1];
            textBox9.Text = sudoku[2, 2];
            //Второй квадрат
            textBox10.Text = sudoku[0, 3];
            textBox11.Text = sudoku[0, 4];
            textBox12.Text = sudoku[0, 5];
            textBox14.Text = sudoku[1, 3];
            textBox15.Text = sudoku[1, 4];
            textBox16.Text = sudoku[1, 5];
            textBox13.Text = sudoku[2, 3];
            textBox17.Text = sudoku[2, 4];
            textBox18.Text = sudoku[2, 5];
            //Третий квадрат
            textBox27.Text = sudoku[0, 6];
            textBox26.Text = sudoku[0, 7];
            textBox25.Text = sudoku[0, 8];
            textBox24.Text = sudoku[1, 6];
            textBox23.Text = sudoku[1, 7];
            textBox22.Text = sudoku[1, 8];
            textBox21.Text = sudoku[2, 6];
            textBox20.Text = sudoku[2, 7];
            textBox19.Text = sudoku[2, 8];
            //Четвертый квадрат
            textBox36.Text = sudoku[3, 0];
            textBox35.Text = sudoku[3, 1];
            textBox34.Text = sudoku[3, 2];
            textBox33.Text = sudoku[4, 0];
            textBox32.Text = sudoku[4, 1];
            textBox31.Text = sudoku[4, 2];
            textBox30.Text = sudoku[5, 0];
            textBox29.Text = sudoku[5, 1];
            textBox28.Text = sudoku[5, 2];
            //Пятый квадрат
            textBox45.Text = sudoku[3, 3];
            textBox44.Text = sudoku[3, 4];
            textBox43.Text = sudoku[3, 5];
            textBox42.Text = sudoku[4, 3];
            textBox41.Text = sudoku[4, 4];
            textBox40.Text = sudoku[4, 5];
            textBox39.Text = sudoku[5, 3];
            textBox38.Text = sudoku[5, 4];
            textBox37.Text = sudoku[5, 5];
            //Шестой квадрат
            textBox54.Text = sudoku[3, 6];
            textBox53.Text = sudoku[3, 7];
            textBox52.Text = sudoku[3, 8];
            textBox51.Text = sudoku[4, 6];
            textBox50.Text = sudoku[4, 7];
            textBox49.Text = sudoku[4, 8];
            textBox48.Text = sudoku[5, 6];
            textBox47.Text = sudoku[5, 7];
            textBox46.Text = sudoku[5, 8];
            //Седьмой квадрат
            textBox63.Text = sudoku[6, 0];
            textBox62.Text = sudoku[6, 1];
            textBox61.Text = sudoku[6, 2];
            textBox60.Text = sudoku[7, 0];
            textBox59.Text = sudoku[7, 1];
            textBox58.Text = sudoku[7, 2];
            textBox57.Text = sudoku[8, 0];
            textBox56.Text = sudoku[8, 1];
            textBox55.Text = sudoku[8, 2];
            //Восьмой квадрат
            textBox72.Text = sudoku[6, 3];
            textBox71.Text = sudoku[6, 4];
            textBox70.Text = sudoku[6, 5];
            textBox69.Text = sudoku[7, 3];
            textBox68.Text = sudoku[7, 4];
            textBox67.Text = sudoku[7, 5];
            textBox66.Text = sudoku[8, 3];
            textBox65.Text = sudoku[8, 4];
            textBox64.Text = sudoku[8, 5];
            //Девятый квадрат
            textBox81.Text = sudoku[6, 6];
            textBox80.Text = sudoku[6, 7];
            textBox79.Text = sudoku[6, 8];
            textBox78.Text = sudoku[7, 6];
            textBox77.Text = sudoku[7, 7];
            textBox76.Text = sudoku[7, 8];
            textBox75.Text = sudoku[8, 6];
            textBox74.Text = sudoku[8, 7];
            textBox73.Text = sudoku[8, 8];
        }
        public static int Kv(string[,] array, string number, int k, int l)
        {
            int chi = 0;
            //Первый
            if (k < 3 && l < 3)
            {
                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        if (array[i, j] == Convert.ToString(number))  //number это текущее число n
                        {
                            chi ++;
                        }
                    }
                }
            }
            //Второй
            if (k < 3 && l >= 3 && l < 6)
            {
                for (int i = 0; i < 3; i++)
                {
                    for (int j = 3; j < 6; j++)
                    {
                        if (array[i, j] == Convert.ToString(number))
                        {
                            chi ++;
                        }
                    }
                }
            }
            //Третий

            if (k < 3 && l >= 6 && l < 9)
            {
                for (int i = 0; i < 3; i++)
                {
                    for (int j = 6; j < 9; j++)
                    {
                        if (array[i, j] == Convert.ToString(number))
                        {
                            chi ++;
                        }
                    }
                }
            }
            return chi;
        }

        //Первый
        //генерация
        public static int Gat = 0;
        private void button3_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int K1,K2;
            timer1.Start();
            timer2.Start();
            if (radioButton1.Checked)
            {
                Gat = 1;
            }
            else if (radioButton2.Checked)
            {
                Gat = 2;
            }
            else if (radioButton3.Checked)
            {
                Gat = 3;
            }

            //база
            //Первый квадрат
            sudoku[0, 0] = "1";
            sudoku[0, 1] = "2";
            sudoku[0, 2] = "3";
            sudoku[1, 0] = "4";
            sudoku[1, 1] = "5";
            sudoku[1, 2] = "6";
            sudoku[2, 0] = "7";
            sudoku[2, 1] = "8";
            sudoku[2, 2] = "9";
            //Второй квадрат
            sudoku[0, 3] = "4";
            sudoku[0, 4] = "5";
            sudoku[0, 5] = "6";
            sudoku[1, 3] = "7";
            sudoku[1, 4] = "8";
            sudoku[1, 5] = "9";
            sudoku[2, 3] = "1";
            sudoku[2, 4] = "2";
            sudoku[2, 5] = "3";
            //Третий квадрат
            sudoku[0, 6] = "7";
            sudoku[0, 7] = "8";
            sudoku[0, 8] = "9";
            sudoku[1, 6] = "1";
            sudoku[1, 7] = "2";
            sudoku[1, 8] = "3";
            sudoku[2, 6] = "4";
            sudoku[2, 7] = "5";
            sudoku[2, 8] = "6";
            //Четвертый квадрат
            sudoku[3, 0] = "2";
            sudoku[3, 1] = "3";
            sudoku[3, 2] = "4";
            sudoku[4, 0] = "5";
            sudoku[4, 1] = "6";
            sudoku[4, 2] = "7";
            sudoku[5, 0] = "8";
            sudoku[5, 1] = "9";
            sudoku[5, 2] = "1";
            //Пятый квадрат
            sudoku[3, 3] = "5";
            sudoku[3, 4] = "6";
            sudoku[3, 5] = "7";
            sudoku[4, 3] = "8";
            sudoku[4, 4] = "9";
            sudoku[4, 5] = "1";
            sudoku[5, 3] = "2";
            sudoku[5, 4] = "3";
            sudoku[5, 5] = "4";
            //Шестой квадрат
            sudoku[3, 6] = "8";
            sudoku[3, 7] = "9";
            sudoku[3, 8] = "1";
            sudoku[4, 6] = "2";
            sudoku[4, 7] = "3";
            sudoku[4, 8] = "4";
            sudoku[5, 6] = "5";
            sudoku[5, 7] = "6";
            sudoku[5, 8] = "7";
            //Седьмой квадрат
            sudoku[6, 0] = "3";
            sudoku[6, 1] = "4";
            sudoku[6, 2] = "5";
            sudoku[7, 0] = "6";
            sudoku[7, 1] = "7";
            sudoku[7, 2] = "8";
            sudoku[8, 0] = "9";
            sudoku[8, 1] = "1";
            sudoku[8, 2] = "2";
            //Восьмой квадрат
            sudoku[6, 3] = "6";
            sudoku[6, 4] = "7";
            sudoku[6, 5] = "8";
            sudoku[7, 3] = "9";
            sudoku[7, 4] = "1";
            sudoku[7, 5] = "2";
            sudoku[8, 3] = "3";
            sudoku[8, 4] = "4";
            sudoku[8, 5] = "5";
            //Девятый квадрат
            sudoku[6, 6] = "9";
            sudoku[6, 7] = "1";
            sudoku[6, 8] = "2";
            sudoku[7, 6] = "3";
            sudoku[7, 7] = "4";
            sudoku[7, 8] = "5";
            sudoku[8, 6] = "6";
            sudoku[8, 7] = "7";
            sudoku[8, 8] = "8";
            //смешиваем столбцы
            do
            {
                Peremeshka(sudoku);

                for (int i = 0; i < 9; i++)
                {
                    for (int j = 0; j < 9; j++)
                    {
                        udokus[i, j] = sudoku[i, j];
                    }
                }
                //закраска
                int Slozhnost = 81;
                if (radioButton1.Checked)
                    Slozhnost = 43;
                if (radioButton2.Checked)
                    Slozhnost = 47;
                if (radioButton3.Checked)
                    Slozhnost = 52;
                for (int x=1;x<Slozhnost;x++)
                {
                    K1 = rnd.Next(0, 9);
                    K2 = rnd.Next(0, 9);
                    if (udokus[K1, K2] == "0")
                        x--;
                    else udokus[K1, K2] = "0";
                }
                for (int i = 0; i < 9; i++)
                {
                    for (int j = 0; j < 9; j++)
                    {
                        SuDo[i, j] = udokus[i, j];
                    }
                }
                int T = 0; //счетчик выполнения цикла
                while (T < 18)
                {
                    kvadrat1.Resh(SuDo, false);
                    T++;
                }
            } while (Proverka(SuDo) == false);
            AntiZamena(udokus);
            Zapis(udokus);

            timer1.Tick += delegate
            {
                button4.Visible = true;
            //    timer1.Stop();
             //   timer1.Enabled = false;
            };
            timer2.Tick += delegate
            {
                timer2.Stop();
                timer2.Enabled = false;
                Chteniye(udokus);
                Hide();
                trueSudoku trueSudoku = new trueSudoku();
                trueSudoku.Owner = this;
                trueSudoku.ShowDialog();

                Close();
            };
        }

        public static void Peremeshka(string[,] sudoku)
        {
            Random rnd = new Random();
            for (int t = 0; t < 10; t++)
            {
                int P1 = rnd.Next(0, 9);
                int P2 = rnd.Next(0, 9);
                for (int i = 0; i < 9; i++)
                {
                    string Za = sudoku[i, P1];
                    sudoku[i, P1] = sudoku[i, P2];
                    sudoku[i, P2] = Za;
                }
                if (Kv(sudoku, sudoku[0, P1], 0, P1) > 1)
                {
                    for (int i = 0; i < 9; i++)
                    {
                        string Za = sudoku[i, P1];
                        sudoku[i, P1] = sudoku[i, P2];
                        sudoku[i, P2] = Za;
                    }
                }
            }
        }

        public static bool Proverka(string[,] sudoku)
        {
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (sudoku[i, j] == "0") return false;
                }
            }
            return true;
        }
        public static void Zamena(string[,] array)
        {
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (array[i, j] == "") array[i, j] = "0";
                }
            }
        }
        public static void AntiZamena(string[,] array)
        {
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (array[i, j] == "0") array[i, j] = "";
                }
            }
        }
       
        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {


        }

        private void button4_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int Z1, Z2;
            bool T = true;
            string[,] dudo = new string[9, 9]; //закодированный
            do
            {
                Z1 = rnd.Next(0, 9);
                Z2 = rnd.Next(0, 9);
                Chteniye(dudo);
                if (dudo[Z1, Z2] == "")
                {
                    dudo[Z1, Z2] = sudoku[Z1, Z2];
                    Zapis(dudo);
                    T = false;
                } 
            } while (T);
            button4.Visible = false;
        }
    }
}
