﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Судоку
{
    public partial class trueSudoku : Form
    {
        public trueSudoku()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewGame frm1 = new NewGame();
            frm1.ShowDialog();
            this.Close();
        }
        public double T = 0;
        private void button2_Click(object sender, EventArgs e)
        {
            NewGame main = this.Owner as NewGame;
            if (main != null)
            {
                string[,] sudoku = main.sudoku;

                textBox1.Text = sudoku[0, 0];
                textBox2.Text = sudoku[0, 1];
                textBox3.Text = sudoku[0, 2];
                textBox4.Text = sudoku[1, 0];
                textBox5.Text = sudoku[1, 1];
                textBox6.Text = sudoku[1, 2];
                textBox7.Text = sudoku[2, 0];
                textBox8.Text = sudoku[2, 1];
                textBox9.Text = sudoku[2, 2];
                //Второй квадрат
                textBox10.Text = sudoku[0, 3];
                textBox11.Text = sudoku[0, 4];
                textBox12.Text = sudoku[0, 5];
                textBox14.Text = sudoku[1, 3];
                textBox15.Text = sudoku[1, 4];
                textBox16.Text = sudoku[1, 5];
                textBox13.Text = sudoku[2, 3];
                textBox17.Text = sudoku[2, 4];
                textBox18.Text = sudoku[2, 5];
                //Третий квадрат
                textBox27.Text = sudoku[0, 6];
                textBox26.Text = sudoku[0, 7];
                textBox25.Text = sudoku[0, 8];
                textBox24.Text = sudoku[1, 6];
                textBox23.Text = sudoku[1, 7];
                textBox22.Text = sudoku[1, 8];
                textBox21.Text = sudoku[2, 6];
                textBox20.Text = sudoku[2, 7];
                textBox19.Text = sudoku[2, 8];
                //Четвертый квадрат
                textBox36.Text = sudoku[3, 0];
                textBox35.Text = sudoku[3, 1];
                textBox34.Text = sudoku[3, 2];
                textBox33.Text = sudoku[4, 0];
                textBox32.Text = sudoku[4, 1];
                textBox31.Text = sudoku[4, 2];
                textBox30.Text = sudoku[5, 0];
                textBox29.Text = sudoku[5, 1];
                textBox28.Text = sudoku[5, 2];
                //Пятый квадрат
                textBox45.Text = sudoku[3, 3];
                textBox44.Text = sudoku[3, 4];
                textBox43.Text = sudoku[3, 5];
                textBox42.Text = sudoku[4, 3];
                textBox41.Text = sudoku[4, 4];
                textBox40.Text = sudoku[4, 5];
                textBox39.Text = sudoku[5, 3];
                textBox38.Text = sudoku[5, 4];
                textBox37.Text = sudoku[5, 5];
                //Шестой квадрат
                textBox54.Text = sudoku[3, 6];
                textBox53.Text = sudoku[3, 7];
                textBox52.Text = sudoku[3, 8];
                textBox51.Text = sudoku[4, 6];
                textBox50.Text = sudoku[4, 7];
                textBox49.Text = sudoku[4, 8];
                textBox48.Text = sudoku[5, 6];
                textBox47.Text = sudoku[5, 7];
                textBox46.Text = sudoku[5, 8];
                //Седьмой квадрат
                textBox63.Text = sudoku[6, 0];
                textBox62.Text = sudoku[6, 1];
                textBox61.Text = sudoku[6, 2];
                textBox60.Text = sudoku[7, 0];
                textBox59.Text = sudoku[7, 1];
                textBox58.Text = sudoku[7, 2];
                textBox57.Text = sudoku[8, 0];
                textBox56.Text = sudoku[8, 1];
                textBox55.Text = sudoku[8, 2];
                //Восьмой квадрат
                textBox72.Text = sudoku[6, 3];
                textBox71.Text = sudoku[6, 4];
                textBox70.Text = sudoku[6, 5];
                textBox69.Text = sudoku[7, 3];
                textBox68.Text = sudoku[7, 4];
                textBox67.Text = sudoku[7, 5];
                textBox66.Text = sudoku[8, 3];
                textBox65.Text = sudoku[8, 4];
                textBox64.Text = sudoku[8, 5];
                //Девятый квадрат
                textBox81.Text = sudoku[6, 6];
                textBox80.Text = sudoku[6, 7];
                textBox79.Text = sudoku[6, 8];
                textBox78.Text = sudoku[7, 6];
                textBox77.Text = sudoku[7, 7];
                textBox76.Text = sudoku[7, 8];
                textBox75.Text = sudoku[8, 6];
                textBox74.Text = sudoku[8, 7];
                textBox73.Text = sudoku[8, 8];

                string[,] udokus = main.udokus;

                textBox162.Text = udokus[0, 0];
                textBox161.Text = udokus[0, 1];
                textBox160.Text = udokus[0, 2];
                textBox159.Text = udokus[1, 0];
                textBox158.Text = udokus[1, 1];
                textBox157.Text = udokus[1, 2];
                textBox156.Text = udokus[2, 0];
                textBox155.Text = udokus[2, 1];
                textBox154.Text = udokus[2, 2];
                //Второй квадрат
                textBox145.Text = udokus[0, 3];
                textBox146.Text = udokus[0, 4];
                textBox147.Text = udokus[0, 5];
                textBox149.Text = udokus[1, 3];
                textBox150.Text = udokus[1, 4];
                textBox151.Text = udokus[1, 5];
                textBox148.Text = udokus[2, 3];
                textBox152.Text = udokus[2, 4];
                textBox153.Text = udokus[2, 5];
                //Третий квадрат
                textBox144.Text = udokus[0, 6];
                textBox143.Text = udokus[0, 7];
                textBox142.Text = udokus[0, 8];
                textBox141.Text = udokus[1, 6];
                textBox140.Text = udokus[1, 7];
                textBox139.Text = udokus[1, 8];
                textBox138.Text = udokus[2, 6];
                textBox137.Text = udokus[2, 7];
                textBox136.Text = udokus[2, 8];
                //Четвертый квадрат
                textBox135.Text = udokus[3, 0];
                textBox134.Text = udokus[3, 1];
                textBox133.Text = udokus[3, 2];
                textBox132.Text = udokus[4, 0];
                textBox131.Text = udokus[4, 1];
                textBox130.Text = udokus[4, 2];
                textBox129.Text = udokus[5, 0];
                textBox128.Text = udokus[5, 1];
                textBox127.Text = udokus[5, 2];
                //Пятый квадрат
                textBox126.Text = udokus[3, 3];
                textBox125.Text = udokus[3, 4];
                textBox124.Text = udokus[3, 5];
                textBox123.Text = udokus[4, 3];
                textBox122.Text = udokus[4, 4];
                textBox121.Text = udokus[4, 5];
                textBox120.Text = udokus[5, 3];
                textBox119.Text = udokus[5, 4];
                textBox118.Text = udokus[5, 5];
                //Шестой квадрат
                textBox117.Text = udokus[3, 6];
                textBox116.Text = udokus[3, 7];
                textBox115.Text = udokus[3, 8];
                textBox114.Text = udokus[4, 6];
                textBox113.Text = udokus[4, 7];
                textBox112.Text = udokus[4, 8];
                textBox111.Text = udokus[5, 6];
                textBox110.Text = udokus[5, 7];
                textBox109.Text = udokus[5, 8];
                //Седьмой квадрат
                textBox108.Text = udokus[6, 0];
                textBox107.Text = udokus[6, 1];
                textBox106.Text = udokus[6, 2];
                textBox105.Text = udokus[7, 0];
                textBox104.Text = udokus[7, 1];
                textBox103.Text = udokus[7, 2];
                textBox102.Text = udokus[8, 0];
                textBox101.Text = udokus[8, 1];
                textBox100.Text = udokus[8, 2];
                //Восьмой квадрат
                textBox99.Text = udokus[6, 3];
                textBox98.Text = udokus[6, 4];
                textBox97.Text = udokus[6, 5];
                textBox96.Text = udokus[7, 3];
                textBox95.Text = udokus[7, 4];
                textBox94.Text = udokus[7, 5];
                textBox93.Text = udokus[8, 3];
                textBox92.Text = udokus[8, 4];
                textBox91.Text = udokus[8, 5];
                //Девятый квадрат
                textBox90.Text = udokus[6, 6];
                textBox89.Text = udokus[6, 7];
                textBox88.Text = udokus[6, 8];
                textBox87.Text = udokus[7, 6];
                textBox86.Text = udokus[7, 7];
                textBox85.Text = udokus[7, 8];
                textBox84.Text = udokus[8, 6];
                textBox83.Text = udokus[8, 7];
                textBox82.Text = udokus[8, 8];


                for (int i = 0; i<9;i++)
                {
                    for (int j =0; j<9; j++)
                    {
                        if (udokus[i, j] == sudoku[i, j]) T++;

                    }
                }
                label4.Visible = true;
                T = T / 81 * 100;
                if (T>= 95)
                {
                    if (NewGame.Gat == 1) NewGame.Expirience += 50;
                    else if (NewGame.Gat == 2) NewGame.Expirience += 75;
                    else if (NewGame.Gat == 3) NewGame.Expirience += 100;
                    label6.Text = Convert.ToString(NewGame.Expirience);
                    label6.Visible = true;
                } else
                {
                    if (NewGame.Gat == 1) NewGame.Expirience -= 25;
                    else if (NewGame.Gat == 2) NewGame.Expirience -= 20;
                    else if (NewGame.Gat == 3) NewGame.Expirience -= 15;
                    label6.Text = Convert.ToString(NewGame.Expirience);
                    label6.Visible = true;
                }
                label4.Text = Convert.ToString(T) + "%";
            }
        }

        private void textBox162_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox150_TextChanged(object sender, EventArgs e)
        {

        }

        private void trueSudoku_Load(object sender, EventArgs e)
        {

        }
    }
}
